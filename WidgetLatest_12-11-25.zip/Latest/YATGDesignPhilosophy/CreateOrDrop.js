define('DS/YATGDesignPhylosophy/CreateOrDrop',
    ["DS/DataDragAndDrop/DataDragAndDrop",
        "UWA/Promise",
        "DS/WAFData/WAFData",
        "DS/YATGRMUtilsServices/UtilService",
    ],
    function (DataDnD, p, WAFData, YATGUtils) {
        'use strict';
        var vSpaceURL = '';
        YATGUtils.getURLs().then(spaceurl => {
            vSpaceURL = spaceurl.url;
        });
        var designCreate = {

            getSpaceUrls: function () {
                return YATGUtils.getURLs().then(spaceurl => {
                    console.log(spaceurl.url);
                    return spaceurl.url;
                });
            },


            dragAndDrop: function () {

                const maincont = document.createElement("div");

                const parentDiv = document.createElement('div');
                parentDiv.className = 'chg-add-member-assignee-field';

                const controlsDiv = document.createElement('div');
                controlsDiv.classList.add('YATG_wux-controls-abstract', 'YATG_wux-controls-autoComplete');

                const selectionChipsDiv = document.createElement('div');
                selectionChipsDiv.classList.add('YATG_wux-controls-abstract', 'YATG_wux-controls-selectionChips', 'with-button', 'YATG_wux-controls-autoComplete-selectionChips');
                selectionChipsDiv.setAttribute('has-menu', 'true');

                const splitDetails = document.createElement('div');
                splitDetails.className = "split-or-container";

                const splitLineLeft = document.createElement('div');
                splitLineLeft.className = 'split-line-left';

                const splitOr = document.createElement('div');
                splitOr.className = 'split-or wux-light-steel';
                splitOr.textContent = 'or';

                const splitLineRight = document.createElement('div');
                splitLineRight.className = 'split-line-right';

                splitDetails.appendChild(splitLineLeft);
                splitDetails.appendChild(splitOr);
                splitDetails.appendChild(splitLineRight);

                selectionChipsDiv.appendChild(splitDetails);

                const createBtn = document.createElement('button');
                createBtn.textContent = "Create New";
                createBtn.className = "drop-action-button";
                selectionChipsDiv.appendChild(createBtn);

                createBtn.addEventListener('click', designCreate.createForm);

                function createChipCell(labelText, docId) {
                    const chipContainer = document.createElement('div');
                    chipContainer.classList.add('YATG_wux-chip-cell-container');
                    chipContainer.setAttribute('draggable', 'true');

                    const img = document.createElement('img');
                    img.id = 'imgid1';
                    img.src = imageURL + 'document_888108.png';
                    img.alt = '';

                    const label = document.createElement('li');
                    label.classList.add('YATG_wux-chip-cell-label');
                    label.id = docId;
                    label.textContent = labelText;

                    const closeButton = document.createElement('li');
                    closeButton.classList.add('YATG_wux-chip-cell-close', 'YATG_wux-ui-3ds', 'YATG_wux-ui-3ds-1x', 'YATG_wux-ui-3ds-close');

                    const closeImg = document.createElement('img');
                    closeImg.id = 'imgid';
                    closeImg.src = imageURL + 'iconActionDelete.png';
                    closeImg.alt = '';

                    closeImg.addEventListener('click', function () {
                        chipContainer.remove();
                    });
                    closeButton.appendChild(closeImg);
                    chipContainer.appendChild(img);
                    chipContainer.appendChild(label);
                    chipContainer.appendChild(closeButton);
                    return chipContainer;
                }
                const lastWidgetDiv = document.createElement('div');
                lastWidgetDiv.classList.add('YATG_wux-controls-lastWidget-selectionChips');
                controlsDiv.appendChild(selectionChipsDiv);
                controlsDiv.appendChild(lastWidgetDiv);
                parentDiv.appendChild(controlsDiv);
                const addedObjectIds = new Set();
                DataDnD.droppable(parentDiv, {
                    enter: function (el, event) {
                        el.classList.add("drag-over");
                    },
                    over: function (el, event) {
                        return true;
                    },
                    leave: function (el, event) {
                        el.classList.remove("drag-over");
                    },
                    drop: function (data, el, event) {
                        console.log(data);
                        const res = JSON.parse(data);

                        const firstDropObject = res.data.items[0];
                        const firstDropObjectID = firstDropObject.objectId;
                        console.log(firstDropObject);

                        //call design Home page fun :-

                        //designCreate.checkIfMouldProduct(firstDropObjectID);
                    }
                });
                maincont.appendChild(parentDiv);
                return maincont;
            },

            createForm: async function () {

                var _baseURL = "";
                var imurl = '';

                await designCreate.getSpaceUrls().then(url => {
                    console.log("Returned URL:", url);
                    imurl = url + "/webapps/YATGReportManagement/assets/images/";
                });


                if (document.getElementById('modal-overlay')) return;
                var overlay = document.createElement('div');
                overlay.id = 'modal-overlay';

                const myDiv = document.createElement('div');
                myDiv.id = 'myDiv';
                myDiv.className = "modal";

                const myDivHeader = document.createElement('div');
                myDivHeader.id = 'myDivHeader';

                const titleContainer = document.createElement('h2');
                titleContainer.textContent = 'New Product';

                const crossContainer = document.createElement('div');
                crossContainer.className = "close-icon";
                const closeImg = document.createElement('img');
                closeImg.id = 'imgid';
                console.log(imurl);
                closeImg.src = imurl + 'closeForm.png';
                closeImg.alt = '';
                console.log(imurl + 'closeForm.png');
                crossContainer.appendChild(closeImg);

                myDivHeader.appendChild(titleContainer);
                myDivHeader.appendChild(crossContainer);
                myDiv.appendChild(myDivHeader);


                const formBOdy = document.createElement('div');
                formBOdy.className = 'formBodyContainer';

                function createOtbForm(labelText, plcHolder, fieldId, isDisable,textAreadiv) {

                    const formLine = document.createElement('div');
                    formLine.className = 'YATG_formLine s12 m12 l12';

                    const flexLine = document.createElement('div');
                    flexLine.className = 'YATG_flexLine';
                    const formLabel = document.createElement('div');
                    formLabel.className = 'YATG_formLabel ENONew_AAe-jzh0g06BLzyy6W02 s12';
                    formLabel.style.cssText = ''; 
                    const attrLabel = document.createElement('div');
                    attrLabel.className = 'YATG_attrLabel YATG_mandAttr';

                    const textContainer = document.createElement('span');
                    textContainer.className = 'YATG_textContainer';

                    const titleSpan = document.createElement('span');
                    titleSpan.innerText = labelText;

                    textContainer.appendChild(titleSpan);
                    attrLabel.appendChild(textContainer);
                    const attrMand = document.createElement('div');
                    attrMand.className = 'YATG_attrMand';
                    attrMand.innerText = ' *';

                    attrLabel.appendChild(attrMand);
                    formLabel.appendChild(attrLabel);

                    const formValue = document.createElement('div');
                    formValue.className = 'YATG_formValue s12';

                    const formTweakerContainer = document.createElement('div');
                    formTweakerContainer.className = 'YATG_formTweakerContainer';
                    formTweakerContainer.id = 'V_Name';

                    const twContainer = document.createElement('div');
                    twContainer.className = 'YATG_tw_container';

                    const twElementsContainer = document.createElement('div');
                    twElementsContainer.className = 'YATG_tw_elementsContainer';

                    const wuxControl = document.createElement('div');
                    wuxControl.className = 'YATG_wux-controls-abstract YATG_wux-controls-lineeditor YATG_wux-controls-lineeditor-width input-text-label';
                    wuxControl.style.width = '100%';

                    if(!textAreadiv){
                        const input = document.createElement('input');
                        input.type = 'text';
                        input.id = fieldId;
                        input.tabIndex = 0;
                        input.autocomplete = 'off';
                        input.className = 'YATG_wux-ui-state-undefined';
                        input.placeholder = plcHolder;
    
                        if (isDisable) {
                            input.disabled = true;
                            input.value = 'YATG_DesignPhilosophy';
                        }

                        wuxControl.appendChild(input);

                    }

                    if (textAreadiv) {
                        attrMand.innerText = ' ';
                        const textarea = document.createElement("textarea");
                        textarea.id = 'eng-description';
                        textarea.className = "YATG_wux-ui-state-undefined";
                        textarea.placeholder = plcHolder;
                        textarea.cols = 20;
                        textarea.rows = 3;
                        textarea.style.width = "98%";
                        wuxControl.appendChild(textarea);
                    }
                    twElementsContainer.appendChild(wuxControl);
                    twContainer.appendChild(twElementsContainer);
                    formTweakerContainer.appendChild(twContainer);
                    formValue.appendChild(formTweakerContainer);

                    flexLine.appendChild(formLabel);
                    flexLine.appendChild(formValue);
                    formLine.appendChild(flexLine);

                    return flexLine;
                }

                function createOtbFormDropDown(labelText, fieldId) {

                    const formLine = document.createElement('div');
                    formLine.className = 'YATG_formLine s12 m12 l12';
                    const flexLine = document.createElement('div');
                    flexLine.className = 'YATG_flexLine';
                    const formLabel = document.createElement('div');
                    formLabel.className = 'YATG_formLabel ENONew_AAe-jzh0g06BLzyy6W02 s12';
                    formLabel.style.cssText = '';

                    const attrLabel = document.createElement('div');
                    attrLabel.className = 'YATG_attrLabel YATG_mandAttr';

                    const textContainer = document.createElement('span');
                    textContainer.className = 'YATG_textContainer';

                    const titleSpan = document.createElement('span');
                    titleSpan.innerText = labelText;

                    textContainer.appendChild(titleSpan);
                    attrLabel.appendChild(textContainer);
                    const attrMand = document.createElement('div');
                    attrMand.className = 'YATG_attrMand';
                    attrMand.innerText = ' *';

                    attrLabel.appendChild(attrMand);
                    formLabel.appendChild(attrLabel);
                    const formValue = document.createElement('div');
                    formValue.className = 'YATG_formValue s12';

                    const formTweakerContainer = document.createElement('div');
                    formTweakerContainer.className = 'YATG_formTweakerContainer';
                    formTweakerContainer.id = 'V_Name';

                    const twContainer = document.createElement('div');
                    twContainer.className = 'YATG_tw_container';

                    const twElementsContainer = document.createElement('div');
                    twElementsContainer.className = 'YATG_tw_elementsContainer';

                    const wuxControl = document.createElement('div');
                    wuxControl.className = 'YATG_wux-controls-abstract YATG_wux-controls-lineeditor YATG_wux-controls-lineeditor-width input-text-label';
                    wuxControl.style.width = '100%';

                    const credentialsSelect = document.createElement('select');
                    credentialsSelect.id = fieldId;
                    wuxControl.appendChild(credentialsSelect);
                    twElementsContainer.appendChild(wuxControl);
                    twContainer.appendChild(twElementsContainer);
                    formTweakerContainer.appendChild(twContainer);
                    formValue.appendChild(formTweakerContainer);

                    flexLine.appendChild(formLabel);
                    flexLine.appendChild(formValue);
                    formLine.appendChild(flexLine);

                    return flexLine;
                }

                formBOdy.appendChild(createOtbForm('Title', 'Enter a value', 'eng-title', false, false));
                formBOdy.appendChild(createOtbForm('Description', 'Enter description', 'eng-description', false, true));

                myDiv.appendChild(formBOdy);

                const footer = document.createElement('div');
                footer.className = 'YATG_wux-windows-dialog-footer resize-padding';

                const buttonsContainer = document.createElement('div');
                buttonsContainer.className = 'YATG_wux-windows-dialog-buttons';
                buttonsContainer.style.maxWidth = '570px';

                const createButton = document.createElement('div');
                createButton.className = 'YATG_wux-controls-abstract YATG_wux-controls-button YATG_wux-ui-style-normal YATG_wux-ui-state-primary';
                createButton.tabIndex = 0;
                createButton.dataset.recId = 'null_Ok';
                const createLabel = document.createElement('span');
                createLabel.className = 'wux-button-label';
                createLabel.textContent = 'Create';
                createButton.appendChild(createLabel);

                const cancelButton = document.createElement('div');
                cancelButton.className = 'YATG_wux-controls-abstract YATG_wux-controls-button YATG_wux-ui-state-secondary YATG_wux-ui-style-normal';
                cancelButton.tabIndex = 0;
                cancelButton.dataset.recId = 'null_Discard';
                const cancelLabel = document.createElement('span');
                cancelLabel.className = 'YATG_wux-button-label';
                cancelLabel.textContent = 'Cancel';
                cancelButton.appendChild(cancelLabel);

                buttonsContainer.appendChild(createButton);
                buttonsContainer.appendChild(cancelButton);
                footer.appendChild(buttonsContainer);
                myDiv.appendChild(footer);

                overlay.appendChild(myDiv);
                document.body.appendChild(overlay);

                cancelButton.addEventListener('click', function () {
                    document.body.removeChild(overlay);
                });

                crossContainer.addEventListener('click', function () {
                    document.body.removeChild(overlay);
                });

                createButton.addEventListener('click', function (e) {
                    e.preventDefault();
                    var ENG_title = document.querySelector('#eng-title').value;
                    var ENG_type = document.querySelector('#eng-type').value;
                    var ENG_Cred = document.querySelector('#eng-cred').value;
                    var ENG_description = document.querySelector('#eng-description').value;

                    if (ENG_title.length < 3) {
                        widget.NotificationsUtil.handler().addNotif({ level: 'error', subtitle: `Fill all required fields `, sticky: true });
                        ;
                        return;
                    }

                    const data = {
                        "items": [
                            {
                                "type": ENG_type,
                                "attributes": {
                                    "title": ENG_title,
                                    "isManufacturable": true,
                                    "description": ENG_description
                                }
                            }
                        ]
                    }
                    YATGUtils.getCSRFToken().then(csrfTok => {
                        console.log("eng type", ENG_type);
                        console.log("descritping", ENG_description);
                        console.log("sec context", ENG_Cred);

                        designCreate.callENGNewItemSer(_baseURL, ENG_Cred, csrfTok, data).then(res => {
                            console.log(res);
                        })
                    }).catch(err => {
                        console.log("error in fetching csrf", err);
                    })
                    document.body.removeChild(overlay);
                });

                YATGUtils.getURLs().then(spaceurl => {
                    _baseURL = spaceurl.url;
                    console.log("this is base usl", _baseURL);
                }).catch(err => {
                    console.error("Error fetching Space URL:", err);
                });
                YATGUtils.getCredentialsList()
                    .then(credentialsList => {
                        console.log(_baseURL);
                        console.log("Credentials List:", credentialsList);

                        const credentialsSelect = document.querySelector('#eng-cred');

                        credentialsList.forEach(cred => {
                            const option = document.createElement('option');
                            option.value = cred.value;
                            option.textContent = cred.withoutOrgNls;
                            credentialsSelect.appendChild(option);
                        });
                    })
                    .catch(err => {
                        console.error("Error fetching credentials list:", err);
                    });

            },

            callENGNewItemSer: function (spaceUrl, secContext, csrfToken, data) {

                return new Promise(function (resolve, reject) {
                    var vURL = spaceUrl + '/resources/v1/modeler/dseng/dseng:EngItem';
                    fetch(vURL, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json',
                            'ENO_CSRF_TOKEN': csrfToken,
                            'SecurityContext': secContext
                        },
                        body: JSON.stringify(data)
                    })
                        .then(res => res.json())
                        .then(res => {
                            console.log("Fetch result", res);
                            const obj = res.member[0];
                            console.log("Fetch result", obj);
                            widget.NotificationsUtil.handler().addNotif({ level: 'success', subtitle: `Design Philosophy Created Successfully \n title : ${obj.title} \n name : ${obj.name} `, sticky: true });
                            //designCreate.createWelcom();
                        })
                        .catch(err => {
                            console.error("Fetch error", err);
                        });
                });
            },

            createWelcom: function () {
                var contentArea = document.querySelector(".YATG-widget-content-area");
                contentArea.innerHTML = "";


            },

            createElementWithClass: function (tag, classNames) {
                const element = document.createElement(tag);
                if (classNames) element.classList.add(...classNames.split(" "));
                return element;
            },

        }

        return designCreate;
    })