define('Solize/Search/Search', ['UWA/Class','DS/i3DXCompassPlatformServices/i3DXCompassPlatformServices','DS/WAFData/WAFData'], function (Class,i3DXCompassPlatformServices,WAFData) {
    var form;

    // Add CSS styles
    var css = `
        .app-container { margin-top: 20px; }
        .class-id-display { margin-bottom: 15px; padding: 10px; background: #f5f5f5; border: 1px solid #ddd; border-radius: 4px; }
        .btn-primary { padding: 12px 24px; font-size: 16px; background: #007acc; color: white; border: none; border-radius: 4px; cursor: pointer; }
        .loading-msg { padding: 20px; text-align: center; background: #e6f3ff; border: 1px solid #b3d9ff; border-radius: 4px; }
        .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; justify-content: center; align-items: center; }
        .modal-content { background: white; border-radius: 8px; padding: 20px; max-width: 90%; max-height: 90%; overflow: auto; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid #ddd; padding-bottom: 10px; }
        .close-btn { background: none; border: none; font-size: 24px; cursor: pointer; color: #666; padding: 0; width: 30px; height: 30px; }
        .instructions { margin-bottom: 15px; padding: 10px; background: #e7f3ff; border: 1px solid #b3d9ff; border-radius: 4px; font-size: 14px; }
        .table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        .table th, .table td { border: 1px solid #ddd; padding: 8px; font-size: 11px; }
        .table th { background: #e6f3ff; text-align: left; font-weight: bold; }
        .table tr:nth-child(even) { background: #f9f9f9; }
        .table tr.clickable { cursor: pointer; transition: background-color 0.2s; }
        .table tr.clickable:hover { background: #e6f3ff !important; }
        .main-container { border: 1px solid #ddd; border-radius: 4px; margin-top: 10px; }
        .title-header { background: #f0f0f0; padding: 10px; border-bottom: 1px solid #ddd; font-weight: bold; }
        .content-container { padding: 15px; }
        .item-details { margin-bottom: 20px; padding: 20px; background: white; border: 1px solid #e0e0e0; border-radius: 6px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .form-field { margin-bottom: 12px; display: flex; flex-direction: column; }
        .form-label { font-weight: bold; margin-bottom: 4px; color: #333; font-size: 14px; }
        .form-input { padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; background: #f8f9fa; color: #333; font-size: 14px; cursor: default; }
        .form-textarea { padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; background: #f8f9fa; color: #333; font-size: 14px; cursor: default; height: 60px; resize: none; font-family: inherit; }
        .error-msg { color: #cc0000; }
        .section-details { margin-bottom: 20px; padding: 10px; background: #f9f9f9; border-radius: 4px; }
    `;
    
    // Inject CSS
    var style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);

    var PlatformServices = Class.singleton({
        getGlobalVariable: function () {
            return this.GlobalVariable || this.setGlobalVariable(), this.GlobalVariable;
        },
        setGlobalVariable: function () {
            this.GlobalVariable = {
                userId: "",
                SecurityContext: "",
                serviceName: "/3dspace",
                baseURL: "",
                tenant: "",
                mySecurityContext: "",
                get3DSpaceURL: function () {
                    return this.baseURL;
                },
                getSwymURL: function () {
                    return this.swymURL;
                },
                getCompassURL: function () {
                    return this.compassURL;
                },
                computeUrl: function (e) {
                    return this.get3DSpaceURL() + e;
                },
                getSecurityContext: function () {
                    return this.SecurityContext;
                },
                getCurrentUser: function () {
                    return this.userId;
                }
            };
        },
        populate3DSpaceURL: function (e) {
            var current = this;
            var global = current.getGlobalVariable();
            return new Promise(function (i, a) {
                i3DXCompassPlatformServices.getPlatformServices({
                    platformId: "OnPremise",
                    onComplete: function (e) {
                        var o = e.hasOwnProperty("length") ? e[0] : e;
                        global.baseURL = e["3DSpace"];
                        global.tenant = e["platformId"];
                        console.log("Platform URL populated:", global.baseURL);
                        i(e);
                    },
                    onFailure: function(error) {
                        console.error("Failed to populate 3DSpace URL:", error);
                        a(error);
                    },
                });
            });
        },
        populateSecurityContext: function () {
            var current = this;
            var global = current.getGlobalVariable();

            var url = global.computeUrl("/resources/pno/person/getsecuritycontext");
            var C = new Date().getTime();
            url = url + "?tenant=" + global.tenant +
                "&current=true&select=preferredcredentials&select=collabspaces" + "&timestamp=" + C;
            return new Promise(function (t, i) {

                WAFData.authenticatedRequest(url, {
                    method: "GET",
                    headers: {
                        "Accept": "application/json",
                    },
                    timeout: 864e5,
                    type: "json",
                    onComplete: function (e) {
                        global.SecurityContext = e.SecurityContext;
                        console.log("Security context populated:", global.SecurityContext);
                        t(e);
                    },
                    onFailure: function (e, t) {
                        var n = e.message;
                        console.error("Failed to populate security context:", n);
                        i(e);
                    },
                    onTimeout: function () {
                        console.log("Security context request timed out");
                        i(new Error("Timeout"));
                    },
                });
            });
        },
        populateCurrentUser: function () {
            var current = this;
            var global = current.getGlobalVariable();
            return new Promise(function (t, a) {
                i3DXCompassPlatformServices.getUser({
                    onComplete: function (n) {
                        global.userId = n.id;
                        console.log("Current user populated:", global.userId);
                        t();
                    },
                    onFailure: function(error) {
                        console.error("Failed to populate current user:", error);
                        a(error);
                    },
                });
            });
        }
    });

    var Application = Class.extend({

        onLoad: function (options) {
            var that = this;
            widget.body.empty();
            console.log('Search application loaded with options:', options);
            
            // Initialize platform services
            this.initializePlatformServices().then(function() {
                console.log("Platform services initialized successfully");
                that.InitiateDialog();
            }).catch(function(error) {
                console.error("Platform services initialization failed:", error);
                // Still show dialog even if initialization fails
                that.InitiateDialog();
            });
        },

        initializePlatformServices: function() {
            var current = this;
            console.log("Initializing platform services...");
            
            return PlatformServices.populate3DSpaceURL()
                .then(function() {
                    return PlatformServices.populateCurrentUser();
                })
                .then(function() {
                    return PlatformServices.populateSecurityContext();
                })
                .then(function() {
                    current.globalVariable = PlatformServices.getGlobalVariable();
                    console.log("All platform services initialized");
                    return current.globalVariable;
                });
        },

        // Method to get engineering item details using dseng:EngItem API
        getEngineeringItemDetails: function(engItemId) {
            var current = this;
            if (!current.globalVariable) {
                return Promise.reject(new Error("Platform services not initialized"));
            }

            // Use the dseng:EngItem endpoint with details mask
            var baseUrl = current.globalVariable.get3DSpaceURL();
            var timestamp = new Date().getTime();
            var url = baseUrl + "/resources/v1/modeler/dseng/dseng:EngItem/" + engItemId + 
                     "?tenant=" + current.globalVariable.tenant + 
                     "&timestamp=" + timestamp +
                     "&$mask=dsmveng:EngItemMask.Details";
            
            console.log("Calling dseng:EngItem API:", url);
            
            return new Promise(function(resolve, reject) {
                WAFData.authenticatedRequest(url, {
                    method: "GET",
                    headers: {
                        "Accept": "application/json",
                        "Accept-Language": "en",
                        "SecurityContext": current.globalVariable.getSecurityContext()
                    },
                    timeout: 30000,
                    type: "json",
                    onComplete: function(response) {
                        console.log("Engineering Item API Success:", response);
                        resolve(response);
                    },
                    onFailure: function(error, details) {
                        console.error("Engineering Item API Failed:", error, details);
                        reject(error);
                    },
                    onTimeout: function() {
                        console.error("Engineering Item API Timeout");
                        reject(new Error("Request timed out"));
                    }
                });
            });
        },

        // Method to fetch engineering details for multiple items
        fetchEngineeringDetailsForItems: function(items) {
            var current = this;
            var promises = [];
            
            items.forEach(function(item, index) {
                if (item.id) {
                    promises.push(
                        current.getEngineeringItemDetails(item.id)
                            .then(function(response) {
                                return {
                                    index: index,
                                    itemId: item.id,
                                    success: true,
                                    data: response
                                };
                            })
                            .catch(function(error) {
                                console.error("Failed to get details for item:", item.id, error);
                                return {
                                    index: index,
                                    itemId: item.id,
                                    success: false,
                                    error: error
                                };
                            })
                    );
                }
            });
            
            return Promise.all(promises);
        },

        // Method to get classified items using the dslib:Class API
        getClassifiedItems: function(classId) {
            var current = this;
            if (!current.globalVariable) {
                return Promise.reject(new Error("Platform services not initialized"));
            }

            // Use the working URL pattern from OpenAPI spec
            var baseUrl = current.globalVariable.get3DSpaceURL();
            var timestamp = new Date().getTime();
            var url = baseUrl + "/resources/v1/modeler/dslib/dslib:Class/" + classId + 
                     "?tenant=" + current.globalVariable.tenant + 
                     "&timestamp=" + timestamp + 
                     "&$mask=dslib:ClassifiedItemsMask";
            
            console.log("Calling dslib:Class API:", url);
            
            return new Promise(function(resolve, reject) {
                WAFData.authenticatedRequest(url, {
                    method: "GET",
                    headers: {
                        "Accept": "application/json",
                        "Accept-Language": "en",
                        "SecurityContext": current.globalVariable.getSecurityContext()
                    },
                    timeout: 30000,
                    type: "json",
                    onComplete: function(response) {
                        console.log("API Success:", response);
                        resolve(response);
                    },
                    onFailure: function(error, details) {
                        console.error("API Failed:", error, details);
                        reject(error);
                    },
                    onTimeout: function() {
                        console.error("API Timeout");
                        reject(new Error("Request timed out"));
                    }
                });
            });
        },

        InitiateDialog: function () {
            var current = this;
            form = document.createElement('form');
            form.classList.add('pure-form');

            const fieldset = document.createElement('fieldset');
            const legend = document.createElement('legend');
            legend.textContent = 'DSLIB CLASS API TEST';
            fieldset.appendChild(legend);

            const classId = "29DF7F1E00000934687DE25C00001B9E";
            
            const classIdDisplay = document.createElement('div');
            classIdDisplay.className = 'class-id-display';
            classIdDisplay.innerHTML = '<strong>Class ID:</strong> ' + classId;

            const searchClass = document.createElement("button");
            searchClass.setAttribute('type', 'button');
            searchClass.setAttribute('id', 'searchClass');
            searchClass.textContent = "Get Class Info & Classified Items";
            searchClass.className = 'btn-primary';

            searchClass.addEventListener("click", function (e) {
                if (!current.globalVariable) {
                    alert("Platform services not initialized. Please refresh and try again.");
                    return;
                }
                current.clearResults();
                current.showLoadingMessage();
                current.getClassifiedItems(classId).then(function(response) {
                    current.hideLoadingMessage();
                    current.showModalTable(response);
                }).catch(function(error) {
                    current.hideLoadingMessage();
                    current.showError("Error: " + (error.message || 'Failed to get class information'));
                });
            });
         
            fieldset.appendChild(classIdDisplay);
            fieldset.appendChild(searchClass);
            form.appendChild(fieldset);

            var responseContainer = document.createElement('div');
            responseContainer.id = 'responseContainer';
            responseContainer.className = 'app-container';

            widget.body.appendChild(form);
            widget.body.appendChild(responseContainer);
        },

        clearResults: function() {
            var responseContainer = document.getElementById('responseContainer');
            if (responseContainer) {
                responseContainer.innerHTML = '';
            }
        },

        showLoadingMessage: function(message) {
            var responseContainer = document.getElementById('responseContainer');
            if (responseContainer) {
                var loadingText = message || 'Fetching class information and classified items...';
                responseContainer.innerHTML = '<div class="loading-msg"><strong>Loading...</strong><br>' + loadingText + '</div>';
            }
        },

        showError: function(errorMessage) {
            var responseContainer = document.getElementById('responseContainer');
            if (responseContainer) {
                responseContainer.innerHTML = '<div class="loading-msg error-msg"><strong>Error:</strong><br>' + errorMessage + '</div>';
            }
        },

        showModalTable: function(response) {
            var current = this;
            
            var modalOverlay = document.createElement('div');
            modalOverlay.id = 'modalOverlay';
            modalOverlay.className = 'modal-overlay';
            
            var modalContent = document.createElement('div');
            modalContent.className = 'modal-content';
            
            var modalHeader = document.createElement('div');
            modalHeader.className = 'modal-header';
            modalHeader.innerHTML = '<h3 style="margin:0;color:#333;">Select Engineering Items</h3>';
            
            var closeButton = document.createElement('button');
            closeButton.textContent = '×';
            closeButton.className = 'close-btn';
            closeButton.addEventListener('click', function() {
                document.body.removeChild(modalOverlay);
            });
            
            modalHeader.appendChild(closeButton);
            modalContent.appendChild(modalHeader);
            
            var instructions = document.createElement('div');
            instructions.className = 'instructions';
            instructions.textContent = 'Click on any row to select an engineering item and display it on the main page.';
            modalContent.appendChild(instructions);
            
            current.createTableContent(response, modalContent, true);
            
            modalOverlay.appendChild(modalContent);
            document.body.appendChild(modalOverlay);
            
            modalOverlay.addEventListener('click', function(e) {
                if (e.target === modalOverlay) {
                    document.body.removeChild(modalOverlay);
                }
            });
        },

        createTableContent: function(response, container, isModal) {
            var current = this;
            
            if (!response || !response.member || response.member.length === 0) {
                container.innerHTML += '<p class="error-msg">No data found or unexpected response format.</p>';
                return;
            }
            
            var classInfo = response.member[0];
            
            if (!isModal) {
                var classDetailsDiv = document.createElement('div');
                classDetailsDiv.className = 'section-details';
                classDetailsDiv.innerHTML = '<h4 style="margin-top:0;">Class Details:</h4>' +
                    '<div><strong>ID:</strong> ' + (classInfo.id || 'N/A') + '</div>' +
                    '<div><strong>Name:</strong> ' + (classInfo.name || 'N/A') + '</div>' +
                    '<div><strong>Title:</strong> ' + (classInfo.title || 'N/A') + '</div>' +
                    '<div><strong>Usage:</strong> ' + (classInfo.classUsage || 'N/A') + '</div>';
                container.appendChild(classDetailsDiv);
            }
            
            if (classInfo.ClassifiedItems && classInfo.ClassifiedItems.member && classInfo.ClassifiedItems.member.length > 0) {
                var items = classInfo.ClassifiedItems.member;
                
                container.innerHTML += '<h4>Classified Items (' + classInfo.ClassifiedItems.totalItems + '):</h4>';
                
                var table = document.createElement('table');
                table.className = 'table';
                table.innerHTML = '<thead><tr><th>#</th><th>ID</th><th>Name</th><th>Title</th><th>Description</th><th>Supplier Part Number</th><th>CAE</th></tr></thead><tbody><tr><td colspan="7" style="text-align:center;padding:20px;font-style:italic;">Loading engineering details...</td></tr></tbody>';
                container.appendChild(table);
                
                var tbody = table.querySelector('tbody');
                
                current.fetchEngineeringDetailsForItems(items).then(function(results) {
                    tbody.innerHTML = '';
                    
                    var engineeringDetailsMap = {};
                    results.forEach(function(result) {
                        if (result.success && result.data && result.data.member && result.data.member.length > 0) {
                            engineeringDetailsMap[result.itemId] = result.data.member[0];
                        }
                    });
                    
                    items.forEach(function(item, index) {
                        var row = document.createElement('tr');
                        var engineeringDetails = engineeringDetailsMap[item.id] || {};
                        
                        if (isModal) {
                            row.className = 'clickable';
                            row.addEventListener('click', function() {
                                var modal = document.getElementById('modalOverlay');
                                if (modal) document.body.removeChild(modal);
                                current.displaySelectedItem(item, engineeringDetails, classInfo);
                            });
                        }
                        
                        var supplierPartNumber = 'N/A';
                        if (engineeringDetails['dseno:EnterpriseAttributes'] && 
                            engineeringDetails['dseno:EnterpriseAttributes'].SupplierPartNumber !== undefined) {
                            supplierPartNumber = engineeringDetails['dseno:EnterpriseAttributes'].SupplierPartNumber;
                        }
                        
                        var caeValue = 'N/A';
                        if (engineeringDetails['dseno:EnterpriseAttributes'] && 
                            engineeringDetails['dseno:EnterpriseAttributes'].CAE !== undefined) {
                            caeValue = engineeringDetails['dseno:EnterpriseAttributes'].CAE ? 'Yes' : 'No';
                        }
                        
                        row.innerHTML = '<td>' + (index + 1) + '</td>' +
                                      '<td style="font-family:monospace;font-size:10px;">' + (item.id || 'N/A') + '</td>' +
                                      '<td>' + (item.name || 'N/A') + '</td>' +
                                      '<td>' + (engineeringDetails.title || 'N/A') + '</td>' +
                                      '<td style="max-width:200px;word-wrap:break-word;">' + (engineeringDetails.description || 'N/A') + '</td>' +
                                      '<td>' + supplierPartNumber + '</td>' +
                                      '<td style="text-align:center;">' + caeValue + '</td>';
                        
                        tbody.appendChild(row);
                    });
                }).catch(function(error) {
                    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:20px;color:#cc0000;">Error loading engineering details: ' + (error.message || 'Unknown error') + '</td></tr>';
                });
            } else {
                container.innerHTML += '<h4>Classified Items:</h4><p style="color:#666;">No classified items found in this class.</p>';
            }
        },

        displaySelectedItem: function(item, engineeringDetails, classInfo) {
            var responseContainer = document.getElementById('responseContainer');
            if (!responseContainer) return;

            responseContainer.innerHTML = '';

            var mainDiv = document.createElement('div');
            mainDiv.className = 'main-container';

            var titleDiv = document.createElement('div');
            titleDiv.className = 'title-header';
            titleDiv.textContent = 'Selected Engineering Item';

            var contentDiv = document.createElement('div');
            contentDiv.className = 'content-container';

            var itemDetailsDiv = document.createElement('div');
            itemDetailsDiv.className = 'item-details';
            itemDetailsDiv.innerHTML = '<h4 style="margin-top:0;">Item Details:</h4>';
            
            var itemDetails = [
                { label: 'ID', value: item.id || 'N/A' },
                { label: 'Name', value: item.name || 'N/A' },
                { label: 'Title', value: engineeringDetails.title || 'N/A' },
                { label: 'Description', value: engineeringDetails.description || 'N/A' },
                { label: 'Supplier Part Number', value: (engineeringDetails['dseno:EnterpriseAttributes'] && 
                    engineeringDetails['dseno:EnterpriseAttributes'].SupplierPartNumber !== undefined) ? 
                    engineeringDetails['dseno:EnterpriseAttributes'].SupplierPartNumber : 'N/A' },
                { label: 'CAE', value: (engineeringDetails['dseno:EnterpriseAttributes'] && 
                    engineeringDetails['dseno:EnterpriseAttributes'].CAE !== undefined) ? 
                    (engineeringDetails['dseno:EnterpriseAttributes'].CAE ? 'Yes' : 'No') : 'N/A' }
            ];
            
            itemDetails.forEach(function(detail) {
                var fieldDiv = document.createElement('div');
                fieldDiv.className = 'form-field';
                
                var label = document.createElement('label');
                label.className = 'form-label';
                label.textContent = detail.label + ':';
                
                if (detail.label === 'Description') {
                    var textarea = document.createElement('textarea');
                    textarea.className = 'form-textarea';
                    textarea.value = detail.value;
                    textarea.readOnly = true;
                    fieldDiv.appendChild(label);
                    fieldDiv.appendChild(textarea);
                } else {
                    var input = document.createElement('input');
                    input.className = 'form-input';
                    input.type = 'text';
                    input.value = detail.value;
                    input.readOnly = true;
                    fieldDiv.appendChild(label);
                    fieldDiv.appendChild(input);
                }
                
                itemDetailsDiv.appendChild(fieldDiv);
            });

            contentDiv.appendChild(itemDetailsDiv);
            mainDiv.appendChild(titleDiv);
            mainDiv.appendChild(contentDiv);
            responseContainer.appendChild(mainDiv);
        },

        showRawResponse: function(response, title) {
            var responseContainer = document.getElementById('responseContainer');
            if (!responseContainer) return;

            responseContainer.innerHTML = '';

            var mainDiv = document.createElement('div');
            mainDiv.className = 'main-container';

            var titleDiv = document.createElement('div');
            titleDiv.className = 'title-header';
            titleDiv.textContent = title || "Class Information";

            var contentDiv = document.createElement('div');
            contentDiv.className = 'content-container';

            this.createTableContent(response, contentDiv, false);
            
            mainDiv.appendChild(titleDiv);
            mainDiv.appendChild(contentDiv);
            responseContainer.appendChild(mainDiv);
        },

        hideLoadingMessage: function() {
            // Loading will be replaced by response or error
        },

        showError: function(errorMessage) {
            var responseContainer = document.getElementById('responseContainer');
            if (responseContainer) {
                responseContainer.innerHTML = '<div style="padding: 15px; background: #ffe6e6; border: 1px solid #ffb3b3; border-radius: 4px; color: #cc0000;"><strong>Error:</strong><br>' + errorMessage + '</div>';
            }
        }


    });

    return Application;

});