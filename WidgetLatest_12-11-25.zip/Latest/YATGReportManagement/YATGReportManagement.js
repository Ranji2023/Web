requirejs.config({
    paths: {
        ExcelJS: "../webapps/YATGReportManagement/lib/exceljs.min",
        jspdf: "../webapps/YATGReportManagement/lib/jspdf.umd.min",
        html2canvas: "../webapps/YATGReportManagement/lib/html2canvas.min",
        pdf_lib: "../webapps/YATGReportManagement/lib/pdf-lib.min",
        xlsx: "../webapps/YATGReportManagement/lib/xlsx.full.min",
        mathjs: "../webapps/YATGReportManagement/lib/math.min"
    },
}),
    define("DS/YATGReportManagement/lib/ExelJsDependency", ["ExcelJS"], function (ExcelJS) {
        return ExcelJS;
    }),
    define("DS/YATGReportManagement/PDFJsDependency", ["jspdf"], function (jspdf) {
        return jspdf;
    }),
    define("DS/YATGReportManagement/HTMLCanvas", ["html2canvas"], function (html2canvas) {
        return html2canvas;
    }),

    define("DS/YATGReportManagement/PDF_LIB", ["pdf_lib"], function (PDFLib) {
        return PDFLib;
    }),

    define("DS/YATGReportManagement/MATHJS", ["mathjs"], function (MATHJS) {
        return MATHJS;
    });

define("DS/YATGReportManagement/XLSX", ["xlsx"], function (XLSX) {
    return XLSX;
});


define('DS/YATGReportManagement/YATGReportManagement',
    ["DS/WAFData/WAFData",
        "DS/YATGReportManagement/HTMLCanvas",
        "DS/DataDragAndDrop/DataDragAndDrop",
        "DS/YATGReportManagement/XLSX",
        "DS/YATGRMUtilsServices/UtilService",
        "DS/YATGRMUtilsServices/NotificationUtils",
        "DS/YATGReportManagement/lib/ExelJsDependency",
        "text!DS/YATGRMUtilsServices/assets/YATGRMWebservises.json",
        "DS/YATGRMUtilsServices/CredentialsServices",
        "UWA/Promise",
        "text!DS/YATGReportManagement/assets/json/dataItems.json",
        "DS/YATGDesignPhilosophy/YATGDesignPhilosophy",
		"DS/Solize/ELGI/PartNumbering",
		"DS/Solize/ELGI/ElgiWidget",
		"text!DS/YATGDesignPhilosophy/assets/templates/customConfigJSON.json"
		
    ],
    function (WAFData, html2canvas, DataDnD, XLSX, YATGUtils, NotificationsUtil, ExcelJS, webServicesUtil, credService, t, UIElements, DesignCreateDrop, PartNumbering, ElgiWidget,customConfigJSON) {

        var webServ = JSON.parse(webServicesUtil);
        var DataItems = JSON.parse(UIElements);
        // Added for EPR Document Upload : Start
        var vData = [];
        var vSpaceURL = "";
        var imageURL = "";
        var _baseURL = "";
        var vSecContextGlobal = "";
        var vFinalDataAttributesGlobal = [];
        var vCollbSpace = "";
		const customConfigurationJSON = JSON.parse(customConfigJSON);
        // Added for EPR Document Upload : End

        var myWidget = {
            onLoadWidget: function () {
                widget.body.innerHTML = "";
                // Added for EPR Document Upload : Start
                widget.NotificationsUtil = new NotificationsUtil();
                YATGUtils.getSecurityContext().then(secContext => {
                    vSecContextGlobal = secContext.SecurityContext;
                    vCollbSpace = vSecContextGlobal.split(".")[2];

                    YATGUtils.getURLs().then(spaceurl => {
                        vSpaceURL = spaceurl.url;
                        _baseURL = spaceurl.url;
                        imageURL = customConfigurationJSON["CustomURL"].CustomDBSpaceURL + "/webapps/YATGReportManagement/assets/images/";
                        var formContainer = myWidget.createFormContainer();
                        widget.body.appendChild(formContainer);
                    })
                }).then(function (e) {
                    return new t(function (e, t) {
                        widget.credentials = new credService;
                        widget.credentials.init(function (t) {
                            e(t)
                        }, function () {
                            t()
                        })
                    })
                })
            },

            createFormContainer: function () {
                var formContainer = this.createElementWithClass('div', "YATG-widget-container");
                formContainer.appendChild(myWidget.createSideBar1())
                return formContainer;
            },

            createSideBar1: function () {
                var sideBar1 = this.createElementWithClass("div", "YATG-widget-sidebar");
                var sideBar1Ul = this.createElementWithClass("ul", "YATG-sideBar1Ul");
                var dummyspace = this.createElementWithClass("div", "YATG-dummysidespace");
                var firNavTitle = this.createElementWithClass("h2", "YATG-secnavhead");

                firNavTitle.textContent = DataItems.sideBar1.title;
                dummyspace.appendChild(firNavTitle);
                sideBar1.appendChild(dummyspace);

                DataItems.sideBar1.items.forEach(({ tile, className }) => {
                    const li = document.createElement("li");

                    if (className) li.className = className;

                    const tileElement = this.createTileElement(
                        tile.title,
                        imageURL + tile.image,
                        tile.subtitle,
                        myWidget[tile.action]
                    );

                    li.appendChild(tileElement);
                    sideBar1Ul.appendChild(li);
                });

                sideBar1.appendChild(sideBar1Ul);
                return sideBar1;
            },


            designPhylosophy: function () {
                var secondSideBar = document.querySelector(".YATG-second-sidebar");
                var contentArea = document.querySelector(".YATG-widget-content-area");
                if (secondSideBar) secondSideBar.style.display = false ? "block" : "none";
                if (contentArea) contentArea.innerHTML = "";

            },

            createTileElement: function (title, imageSrc, subtitle, onclickFunc) {
                var tileContainer = this.createElementWithClass("div", "YATG-tile-container");
                var tileSubContainer = this.createElementWithClass("div", "YATG-tile-sub-container");
                tileSubContainer.setAttribute("draggable", "true");

                var tileHeader = this.createElementWithClass("div", "YATG-tile-header");
                var img = this.createElementWithClass("img", "YATG-tile-image portrait");
                img.src = imageSrc;
                img.setAttribute("draggable", "false");
                tileHeader.appendChild(img);

                var tileBody = this.createElementWithClass("div", "YATG-tile-body");
                var tileTitle = this.createElementWithClass("div", "YATG-tile-title");
                tileTitle.textContent = title;
                var tileSubtitle = this.createElementWithClass("div", "YATG-tile-subtitle");
                tileSubtitle.textContent = subtitle;
                tileBody.appendChild(tileTitle);
                tileBody.appendChild(tileSubtitle);

                tileSubContainer.appendChild(tileHeader);
                tileSubContainer.appendChild(tileBody);
                tileContainer.appendChild(tileSubContainer);

                tileContainer.addEventListener("click", function () {
                    var currentSelected = document.querySelector(".YATG-tile-container.selected");
                    if (currentSelected) { currentSelected.classList.remove("selected"); }
                    tileContainer.classList.add("selected");
                    onclickFunc();
                });

                return tileContainer;
            },

            createSideBar2: function () {
                myWidget.createDynamicSideBar2("Test Report Management", DataItems.sideBar2.TestReprot);
            },

            createDesignSideBar2: function () {
                myWidget.createDynamicSideBar2("TPL", DataItems.sideBar2.TPL);
            },

            createDynamicSideBar2: function (title, items) {
                const oldSidebar = document.querySelector(".YATG-second-sidebar");
                if (oldSidebar) oldSidebar.remove();

                const oldContainer = document.querySelector(".YATG-widget-content-area");
                if (oldContainer) oldContainer.remove();

                const widgetContainer = document.querySelector(".YATG-widget-container");

                const sideBar2 = this.createElementWithClass("div", "YATG-second-sidebar");
                sideBar2.style.display = "none";

                sideBar2.appendChild(this.createBackArrow(title));
                sideBar2.appendChild(this.createSecondSidebarList(items));

                widgetContainer.appendChild(sideBar2);
                const widgetContentArea = this.createElementWithClass("div", "YATG-widget-content-area");
                widgetContainer.appendChild(this.createSpinnerLoad());
                widgetContainer.appendChild(widgetContentArea);
                sideBar2.style.display = "block";
            },


            createSpinnerLoad: function () {
                // Create the outermost div
                const mask = document.createElement("div");
                mask.className = "mask";
                mask.id = "spinnerPopup";
                mask.style.position = "absolute";

                // Create wrapper
                const maskWrapper = document.createElement("div");
                maskWrapper.className = "mask-wrapper";

                // Create content container
                const maskContent = document.createElement("div");
                maskContent.className = "mask-content";

                // Create spinner div
                const spinner = document.createElement("div");
                spinner.className = "spinner spinning fade in";
                spinner.style.transform = "translate3d(0px, 0px, 0px)";
                spinner.style.display = "inline-block";

                // Create spinner bars
                const bar0 = document.createElement("span");
                bar0.className = "spinner-bar";

                const bar1 = document.createElement("span");
                bar1.className = "spinner-bar spinner-bar1";

                const bar2 = document.createElement("span");
                bar2.className = "spinner-bar spinner-bar2";

                const bar3 = document.createElement("span");
                bar3.className = "spinner-bar spinner-bar3";

                // Append bars to spinner
                spinner.appendChild(bar0);
                spinner.appendChild(bar1);
                spinner.appendChild(bar2);
                spinner.appendChild(bar3);

                // Create loading text
                const text = document.createElement("span");
                text.className = "text";
                text.textContent = "Loading...";

                // Build the final structure
                maskContent.appendChild(spinner);
                maskContent.appendChild(text);
                maskWrapper.appendChild(maskContent);
                mask.appendChild(maskWrapper);

                // Add to body or another element
                return mask;

            },

            createBackArrow: function (title) {
                var backArrow = document.createElement("div");
                backArrow.style.display = "flex";
                backArrow.style.alignItems = "center";
                backArrow.style.cursor = "pointer";

                var img = document.createElement("img");
                img.src = imageURL + "Expand_Collapse_pressed.png";
                img.className = "backarro_icon_style";
                img.alt = "Arrow Icon";
                img.style.width = "20px";
                img.style.marginRight = "10px";
                img.style.transition = "transform 0.5s ease";
                img.style.transform = "rotate(0deg)";

                var secNavTitle = document.createElement("h2");
                secNavTitle.className = "YATG-secnavhead";
                secNavTitle.textContent = title;

                backArrow.appendChild(img);
                backArrow.appendChild(secNavTitle);

                backArrow.addEventListener("click", myWidget.toggleSidebar1);

                return backArrow;
            },

            createSecondSidebarList: function (items) {
                var ul2 = document.createElement("ul");
                items.forEach(function (item) {
                    var listItem = myWidget.createSecondSidebarItem(item.text, imageURL + item.image, item.title, myWidget[item.callback]);
                    ul2.appendChild(listItem);
                });
                return ul2;
            },

            buttonEmptyFuncion: function () {

            },

            createSecondSidebarItem: function (title, imageSrc, subtitle, onclickFuncName) {
                var li = document.createElement("li");
                var tileContainer = this.createElementWithClass("div", "YATG-tile-container");
                var tileSubContainer = this.createElementWithClass("div", "YATG-tile-sub-container");
                tileSubContainer.setAttribute("draggable", "true");
                var tileHeader = this.createElementWithClass("div", "YATG-tile-header");
                var img = document.createElement("img");
                img.src = imageSrc;
                img.className = "YATG-tile-image portrait";
                img.setAttribute("draggable", "false");
                tileHeader.appendChild(img);
                var tileBody = this.createElementWithClass("div", "YATG-tile-body");
                var tileTitle = this.createElementWithClass("div", "YATG-tile-title");
                tileTitle.textContent = title;
                var tileSubtitle = this.createElementWithClass("div", "YATG-tile-subtitle");
                tileSubtitle.textContent = subtitle;
                tileBody.appendChild(tileTitle);
                tileBody.appendChild(tileSubtitle);
                tileSubContainer.appendChild(tileHeader);
                tileSubContainer.appendChild(tileBody);
                tileContainer.appendChild(tileSubContainer);
                tileContainer.addEventListener("click", function () {

                    var img = document.querySelector(".backarro_icon_style")
                    var sidebar = document.querySelector(".YATG-widget-sidebar");
                    var isHidden = getComputedStyle(sidebar).display === "block";

                    if (isHidden) {
                        sidebar.style.display = "none";
                        img.style.transform = "rotate(180deg)";
                    }
                    var currentSelected = document.querySelector(".YATG-tile-container.selected");
                    if (currentSelected) { currentSelected.classList.remove("selected"); }
                    tileContainer.classList.add("selected");
                    onclickFuncName();
                });
                li.appendChild(tileContainer);
                return li;
            },

            createSecondSidebar: function () { document.querySelector(".YATG-second-sidebar").style.display = "block"; },

            toggleSidebar1: function () {
                var img = document.querySelector(".backarro_icon_style")
                var sidebar = document.querySelector(".YATG-widget-sidebar");
                var isHidden = getComputedStyle(sidebar).display === "none";

                if (isHidden) {
                    sidebar.style.display = "block";
                    img.style.transform = "rotate(0deg)";
                } else {
                    sidebar.style.display = "none";
                    img.style.transform = "rotate(180deg)";
                }
            },

            showEPRCompButtons: function () { myWidget.createMainSkeleton("EPR Comparison Report (Excel)", myWidget.setBtnEPRComp); },
            showEPRRepButtons: function () { myWidget.createMainSkeleton(" EPR Report Configuration", myWidget.setBtnEPRRep); },
            showEPRRevButtons: function () { myWidget.createMainSkeleton(" EPR Review Configuration", myWidget.setBtnEPRRev); },
            showErpUplaod: function () { myWidget.createMainSkeleton("EPR Upload Configuration", myWidget.setBtnEPRUpload); },
            showTPRButtons: function () { myWidget.createMainSkeleton("TPR Configuration", myWidget.setBtnTPRDownload); },

            ShowDesignPhyCreateOb: function () { myWidget.createMainSkeleton("", myWidget.parmDesignCreateDiv); },
            ShowPartNumberingOb: function () { myWidget.createMainSkeleton("Part Numbering", myWidget.parmPartNumberDiv); },
            showControlledCopyButtons: function () { myWidget.createMainSkeleton("Generate Controlled Copy (PDF)", myWidget.paramGenerateReportDiv); },
            ShowMouldToTireOb: function () { myWidget.createMainSkeleton("Mould To Tire Growth Caluclations", myWidget.createMouldToTire); },


            createMainSkeleton: function (_mainTitle, paramDIv) {
                var contentArea = document.querySelector(".YATG-widget-content-area");
                contentArea.innerHTML = "";
                var contentArea1 = this.createElementWithClass("div", "YATG-skeleton-panel");
                var titlediv = myWidget.titleERPDiv(_mainTitle);
                var contentContainer = myWidget.mainERPdiv(paramDIv);
                contentArea1.appendChild(titlediv);
                contentArea1.appendChild(contentContainer);
                contentArea.appendChild(contentArea1);
            },

            mainERPdiv: function (paramDIv) {
                const mainBodyDiv = this.createDiv("YATG-facetviews");
                mainBodyDiv.appendChild(paramDIv());
                return mainBodyDiv;
            },

            titleERPDiv: function (maintitlename) {
                const skeletonIdCnt = this.createDiv("YATG-skeleton-id-cnt");
                const idCard = this.createDiv("YATG-id-card YATG-without-banner YATG-without-thumbnail YATG-without-facets ready");
                const bannerSection = this.createDiv("YATG-banner-section");
                const mainSection = this.createDiv("YATG-main-section");
                const infoAndThumbnailSection = this.createDiv("YATG-info-and-thumbnail-section");
                const thumbnailSection = this.createDiv("YATG-thumbnail-section");
                const infoSection = this.createDiv("YATG-info-section");
                const headerSection = this.createDiv("YATG-header-section");
                const titleSection = this.createDiv("YATG-title-section");
                const title = document.createElement("h1");
                const span = document.createElement("span");
                span.textContent = maintitlename;
                title.appendChild(span);
                titleSection.appendChild(title);

                const actionsSection = this.createDiv("YATG-actions-section");
                headerSection.appendChild(titleSection);
                headerSection.appendChild(actionsSection);

                const detailedInfoSection = this.createDiv("YATG-detailed-info-section");
                const ownerNameSection = this.createDiv("YATG-owner-name-section");
                infoSection.appendChild(headerSection);
                infoSection.appendChild(detailedInfoSection);

                infoAndThumbnailSection.appendChild(thumbnailSection);
                infoAndThumbnailSection.appendChild(infoSection);

                mainSection.appendChild(infoAndThumbnailSection);

                idCard.appendChild(bannerSection);
                idCard.appendChild(mainSection);

                skeletonIdCnt.appendChild(idCard);

                document.body.appendChild(skeletonIdCnt);

                return skeletonIdCnt;
            },
            setBtnEPRComp: function () { return myWidget.paramERPDiv(myWidget.EPRCompFun); },
            setBtnEPRRep: function () { return myWidget.paramERPDiv(myWidget.EprRepFun); },
            setBtnEPRRev: function () { return myWidget.paramERPDiv(myWidget.EPRRevPDFfun); },
            setBtnEPRUpload: function () { return myWidget.paramERPUpoad(); },
            setBtnTPRDownload: function () { return myWidget.paramERPDiv(myWidget.TPRPdfFun); },

            paramERPUpoad() {
                const div1 = this.createDiv("YATG-scroller YATG-scroller-root", "parametersDiv");
                const div2 = this.createDiv("YATG-no-native-scrollbars YATG-scroller-content");
                const div3 = this.createDiv("YATG-divided YATG-filled YATG-accordion YATG-accordion-root");
                div3.appendChild(myWidget.parmERPUploadcontent());
                div2.appendChild(div3);
                div1.appendChild(div2);
                return div1;

            },

            paramERPDiv: function (btnonclickFun) {
                const div1 = this.createDiv("YATG-scroller YATG-scroller-root", "parametersDiv");
                const div2 = this.createDiv("YATG-no-native-scrollbars YATG-scroller-content");
                const div3 = this.createDiv("YATG-divided YATG-filled YATG-accordion YATG-accordion-root");
                div3.appendChild(myWidget.parmERPDownloadcontent("file-type-excel.svg", btnonclickFun));
                div2.appendChild(div3);
                div1.appendChild(div2);

                return div1;
            },

            parmDesignCreateDiv: function () {
				const div1 = myWidget.createDiv("YATG-scroller YATG-scroller-root", "parametersDiv");
                const div2 = myWidget.createDiv("YATG-no-native-scrollbars YATG-scroller-content");
                const div3 = myWidget.createDiv("YATG-divided YATG-filled YATG-accordion YATG-accordion-root");

                const div4 = myWidget.createDiv("YATG-accordion-item active");
                const contentWrapper = myWidget.createDiv("YATG-content-wrapper");
                const contentDiv = myWidget.createDiv("YATG-content");
                //const dtatadragdiv = DesignCreateDrop.dragAndDrop();
                const dtatadragdiv = DesignCreateDrop.createForm();
                contentDiv.appendChild(dtatadragdiv);
                contentWrapper.appendChild(contentDiv);
                div4.appendChild(contentWrapper);
                div3.appendChild(div4);
                div2.appendChild(div3);
                div1.appendChild(div2);

                return div1;
                
            },
			
			parmPartNumberDiv: function () {
				const div1 = myWidget.createDiv("YATG-scroller YATG-scroller-root", "parametersDiv");
                const div2 = myWidget.createDiv("YATG-no-native-scrollbars YATG-scroller-content");
                const div3 = myWidget.createDiv("YATG-divided YATG-filled YATG-accordion YATG-accordion-root");

                const div4 = myWidget.createDiv("YATG-accordion-item active");
                const contentWrapper = myWidget.createDiv("YATG-content-wrapper");
                const contentDiv = myWidget.createDiv("YATG-content");
                //const dtatadragdiv = DesignCreateDrop.dragAndDrop();
                const dtatadragdiv = PartNumbering.onLoadWidget();
                contentDiv.appendChild(dtatadragdiv);
                contentWrapper.appendChild(contentDiv);
                div4.appendChild(contentWrapper);
                div3.appendChild(div4);
                div2.appendChild(div3);
                div1.appendChild(div2);

                return div1;
                
            },
			
			paramGenerateReportDiv: function () {
				const div1 = myWidget.createDiv("YATG-scroller YATG-scroller-root", "parametersDiv");
                const div2 = myWidget.createDiv("YATG-no-native-scrollbars YATG-scroller-content");
                const div3 = myWidget.createDiv("YATG-divided YATG-filled YATG-accordion YATG-accordion-root");

                const div4 = myWidget.createDiv("YATG-accordion-item active");
                const contentWrapper = myWidget.createDiv("YATG-content-wrapper");
                const contentDiv = myWidget.createDiv("YATG-content");
                //const dtatadragdiv = PartNumbering.onLoadWidget();
                const dtatadragdiv = ElgiWidget.paramCtrlCopyDiv();
                contentDiv.appendChild(dtatadragdiv);
                contentWrapper.appendChild(contentDiv);
                div4.appendChild(contentWrapper);
                div3.appendChild(div4);
                div2.appendChild(div3);
                div1.appendChild(div2);

                return div1;
                
            },

            createMouldToTire: function () {

                const div1 = myWidget.createDiv("YATG-scroller YATG-scroller-root", "parametersDiv");
                const div2 = myWidget.createDiv("YATG-no-native-scrollbars YATG-scroller-content");
                const div3 = myWidget.createDiv("YATG-divided YATG-filled YATG-accordion YATG-accordion-root");

                const div4 = myWidget.createDiv("YATG-accordion-item active");
                const contentWrapper = myWidget.createDiv("YATG-content-wrapper");
                const contentDiv = myWidget.createDiv("YATG-content");
                calcMouldtoTIre.init().then(() => {
                    const dtatadragdiv = calcMouldtoTIre.dragAndDrop();
                    contentDiv.appendChild(dtatadragdiv);
                });
                contentWrapper.appendChild(contentDiv);
                div4.appendChild(contentWrapper);
                div3.appendChild(div4);
                div2.appendChild(div3);
                div1.appendChild(div2);

                return div1;
            },

            parmERPUploadcontent: function () {
                const div4 = this.createDiv("YATG-accordion-item active");
                const contentWrapper = this.createDiv("YATG-content-wrapper");
                const contentDiv = this.createDiv("YATG-content");

                const temContainerDiv = this.createDiv("enox-import-template-download-container");
                const div = document.createElement('div');
                div.className = 'enox-import-template-download';
                const img = document.createElement('img');
                img.src = imageURL + 'I_DownloadTemplete.png';

                div.appendChild(img);
                div.appendChild(document.createTextNode('\u00A0Download\u00A0Template'));
                temContainerDiv.appendChild(div);
                contentDiv.appendChild(temContainerDiv);
                div.addEventListener('click', function () {
                    YATGUtils.downloadDocument(webServ.EPR_EmptyTemplate.url, webServ.EPR_EmptyTemplate.verb);
                })
                const parUploadDiv = this.createDiv("parUploadDiv");
                const btnContainerdiv = this.createElementWithClass('div', 'btnContainerdiv');
                const downloadPopupbtn = this.createDiv("downloadPopup");
                downloadPopupbtn.id = "downloadPopup";
                const loaderdiv = this.createDiv("Download-spinner");
                const downladptag = document.createElement('p');
                downladptag.textContent = "Downloading......";

                downloadPopupbtn.appendChild(loaderdiv);
                downloadPopupbtn.appendChild(downladptag)
                btnContainerdiv.appendChild(downloadPopupbtn);


                const childUploadDiv1 = this.createDiv("childUploadDiv1");
                childUploadDiv1.appendChild(this.createFileInputCell("250px"));

                const childUploadDiv2 = this.createDiv("childUploadDiv2");
                childUploadDiv2.appendChild(this.createButtonCellUpload("250px", "uploadFileIcon.png", "Upload Selected File", "Upload"));

                parUploadDiv.appendChild(childUploadDiv1);
                parUploadDiv.appendChild(childUploadDiv2);

                contentDiv.appendChild(btnContainerdiv);
                contentDiv.appendChild(parUploadDiv);
                contentWrapper.appendChild(contentDiv);

                div4.appendChild(contentWrapper);

                return div4;
            },

            parmERPDownloadcontent: function (downloadIcon, btnonclickFun) {
                const div4 = this.createDiv("YATG-accordion-item active");
                const contentWrapper = this.createDiv("YATG-content-wrapper");
                const contentDiv = this.createDiv("YATG-content");
                contentDiv.appendChild(myWidget.dragAndDropFile());
                contentWrapper.appendChild(contentDiv);
                const btnContainerdiv = this.createElementWithClass('div', 'btnContainerdiv');
                const downloadPopupbtn = this.createDiv("downloadPopup");
                downloadPopupbtn.id = "downloadPopup";
                const loaderdiv = this.createDiv("Download-spinner");
                const downladptag = document.createElement('p');
                downladptag.textContent = "Downloading........";

                downloadPopupbtn.appendChild(loaderdiv);
                downloadPopupbtn.appendChild(downladptag)
                btnContainerdiv.appendChild(downloadPopupbtn);

                btnContainerdiv.appendChild(this.createButtonCell("downloadIcon.png", "Download Selected File", "Download", btnonclickFun));
                contentDiv.appendChild(btnContainerdiv);
                div4.appendChild(contentWrapper);

                return div4;
            },

            createDiv: function (classNames, id, styles = {}) {
                const div = document.createElement("div");
                if (classNames) div.classList.add(...classNames.split(" "));
                if (id) div.id = id;
                for (const [key, value] of Object.entries(styles)) { div.style[key] = value; }
                return div;
            },

            createElementWithClass: function (tag, classNames) {
                const element = document.createElement(tag);
                if (classNames) element.classList.add(...classNames.split(" "));
                return element;
            },

            createTableCell: function (width, align, elementType, textContent, fontSize, additionalClasses) {
                const td = document.createElement("td");
                td.setAttribute("width", width);
                td.setAttribute("align", align);

                const element = document.createElement(elementType);
                if (textContent) element.textContent = textContent;
                if (textContent) element.style.marginLeft = "20px";
                if (fontSize) element.style.fontSize = fontSize;
                if (additionalClasses) element.classList.add(...additionalClasses.split(" "));

                td.appendChild(element);
                return td;
            },

            createEMPtySpacetr: function () {
                const td = document.createElement("td");
                td.setAttribute("width", width);
            },

            createFileInputCell: function (width) {
                const td = document.createElement("div");
                td.setAttribute("width", width);
                td.setAttribute("align", "center");

                const inputWrapper = this.createDiv("YATG-xml-file-input YATG-uwa-file YATG-uwa-file-root YATG-uwa-input YATG-uwa-input-root", "ImportFileInput");
                inputWrapper.style.width = "350px";

                const inputFile = document.createElement("input");
                inputFile.setAttribute("type", "file");
                inputFile.setAttribute("accept", ".xls,.xlsx");
                inputFile.classList.add("YATG-xml-file-input", "YATG-uwa-file-input", "YATG-uwa-input-input", "hidden-input");
                // Added for EPR Document Upload : Start
                inputFile.addEventListener("change", async function (event) {

                    const selectedFile = event.target.files[0];
                    const fileName = selectedFile.name;
                    document.querySelector("#fileName").textContent = this.files[0].name;

                    if (fileName != "") {
                        inputFile.id = "inputFile";
                    }
                    var reader = new FileReader();
                    reader.readAsArrayBuffer(event.target.files[0]);
                    reader.onload = async function (event) {
                        var work_book = XLSX.read(reader.result);
                        var sheet_name = work_book.SheetNames;
                        var tempData = XLSX.utils.sheet_to_json(work_book.Sheets[sheet_name[0]], { header: 1 });
                        try {
                            const data = JSON.parse(EPRTemplateJson);
                            if (!Array.isArray(data) || data.length === 0 || !data[0]?.pages) {
                                throw new Error("Invalid or missing data/pages in EPRTemplateJson");
                            }
                            console.log("EPRJSON :", data);
                            data.forEach(sheet => {
                                if (sheet?.sheetName) {
                                    console.log("Sheet Name :", sheet.sheetName);
                                    if (sheet.sheetName == "EPR") {
                                        const Pages = sheet.pages;
                                        console.log("Pages : ", Pages);
                                        let attributeArrays = [];
                                        Pages.forEach(page => {
                                            if (page?.cells) {
                                                const attributeCells = page.cells.filter(cell => cell?.type === "Attribute");
                                                attributeArrays = attributeArrays.concat(attributeCells);
                                            }
                                        });
                                        const vFinalDataAttributes = [];
                                        let forbiddenEntries = [];
                                        attributeArrays.forEach(attribute => {
                                            const cellRowPosition = attribute?.rowStart;
                                            const cellColumnPosition = attribute?.colStart;
                                            let attrValue = "";
                                            if (tempData?.[cellRowPosition] && typeof tempData[cellRowPosition][cellColumnPosition] !== "undefined") {
                                                attrValue = tempData[cellRowPosition][cellColumnPosition];
                                                if (attrValue == null) attrValue = "";
                                                else attrValue = attrValue.toString();
                                            }

                                            let attrName = attribute?.value ?? "";
                                            const forbiddenChars = attribute?.forbiddenChar || "";
                                            if (forbiddenChars) {
                                                for (let i = 0; i < forbiddenChars.length; i++) {
                                                    if (attrValue.includes(forbiddenChars[i])) {
                                                        forbiddenEntries.push({ attrName, attrValue });
                                                        break;
                                                    }
                                                }
                                            }

                                            vFinalDataAttributes.push({
                                                attrName: attrName,
                                                attrValue: attrValue
                                            });
                                        });

                                        if (forbiddenEntries.length > 0) {
                                            console.log("Forbidden Entries Found:", forbiddenEntries);

                                        }

                                        vFinalDataAttributesGlobal = vFinalDataAttributes;

                                        console.log(vFinalDataAttributes);
                                    }
                                }
                            });

                        } catch (error) {
                            console.error('Failed to fetch or process data:', error);
                        }

                    }
                });
                inputFile.addEventListener("cancel", function (event) {
                    event.target.files[0] = "";
                    vData = [];
                    document.querySelector("#fileName").textContent = "";
                });

                // Added for EPR Document Upload : End

                const divContent = this.createDiv("xml-file-input uwa-file-content uwa-input-content xml-file-input uwa-file-split uwa-input-split");
                const divText = this.createDiv("xml-file-input uwa-file-text uwa-input-text");
                divText.innerHTML = "&nbsp;";
                divText.id = "fileName";

                const divButton = this.createDiv("xml-file-input uwa-file-button uwa-input-button");
                divButton.textContent = "Browse...";

                divContent.appendChild(divText);
                divContent.appendChild(divButton);
                inputWrapper.appendChild(inputFile);
                inputWrapper.appendChild(divContent);
                td.appendChild(inputWrapper);

                return td;
            },

            createButtonCell: function (iconClass, title, buttonText, btnonclickFun) {

                const button = document.createElement("button");
                button.setAttribute("type", "button");
                button.setAttribute("title", title);
                button.classList.add("btn-primary", "btn", "btn-root", "btn-with-icon");
                button.style.width = "190px";

                const buttonIcon = document.createElement("img");
                buttonIcon.src = imageURL + iconClass;
                buttonIcon.className = "arro_icon_style";
                buttonIcon.alt = "Arrow Icon";
                buttonIcon.style.width = "10";
                buttonIcon.style.height = "10px";
                buttonIcon.style.marginRight = "10px";
                buttonIcon.style.alignItems = "left";
                const buttonTextNode = document.createTextNode(buttonText);
                const caretSpan = this.createElementWithClass("span", "caret");

                button.appendChild(buttonIcon);
                button.appendChild(buttonTextNode);
                button.appendChild(caretSpan);

                if (btnonclickFun) button.addEventListener("click", btnonclickFun);

                return button;
            },

            createButtonCellUpload: function (width, iconClass, title, buttonText, btnonclickFun) {
                const td = document.createElement("td");
                td.setAttribute("width", width);
                td.setAttribute("height", "35px")
                td.setAttribute("align", "left");

                const button = document.createElement("button");
                button.setAttribute("type", "button");
                button.setAttribute("title", title);
                button.classList.add("btn-primary", "btn", "btn-root", "btn-with-icon");
                button.style.width = "190px";

                const buttonIcon = document.createElement("img");
                buttonIcon.src = imageURL + iconClass;
                buttonIcon.className = "arro_icon_style";
                buttonIcon.alt = "Arrow Icon";
                buttonIcon.style.width = "20";
                buttonIcon.style.height = "20px";
                buttonIcon.style.marginRight = "10px";
                buttonIcon.style.alignItems = "left";
                const buttonTextNode = document.createTextNode(buttonText);
                const caretSpan = this.createElementWithClass("span", "caret");

                button.appendChild(buttonIcon);
                button.appendChild(buttonTextNode);
                button.appendChild(caretSpan);
                td.appendChild(button);

                if (title == "Upload Selected File") {
                    button.addEventListener("click", function (e) {
                        var currentSecContext = widget.getValue("credentials", t.preferredSecurityContext);
                        console.log(currentSecContext);
                        var fileName = document.getElementById("fileName").textContent;
                        fileName = fileName.trim();
                        if (fileName == "") widget.NotificationsUtil.handler().addNotif({ level: 'warning', subtitle: "Please select file", sticky: true });
                        else if (currentSecContext == "VPLMAdmin.Company Name.Default") myWidget.setNotificationAlert('warning', " Upload failed \n Can't create Document in Default Collaborative Space \n please select proper credentials ");

                        if (fileName != "" && currentSecContext != "VPLMAdmin.Company Name.Default") {
                            button.disabled = true;
                            button.id = "xlsuploadButton";
                            document.querySelector("#inputFile").disabled = true;
                            myWidget.createDocuments(vFinalDataAttributesGlobal);
                            vFinalDataAttributesGlobal = [];
                        }
                    });
                }
                // Added for EPR Document Upload : End
                return td;
            },

            // Added for EPR Document Upload : Starts
            createDocuments: function (vFinalDataAttributes) {

                var vFinalPostBody = {};
                var vFinalData = {};
                var vDataWeb = [];
                var vDataElements = {};
                var vDocumentIndividual = {};
                vDataElements.policy = "Document Release";
                vDataElements.state = "IN_WORK";
                vDataElements.title = "EPR Details";
                vDataElements.description = "EPR Details";
                vDataElements.collabspace = vCollbSpace;
                vDataElements.extensions = ["IPML.Automatic"];
                vDocumentIndividual.type = "Document";
                vDocumentIndividual.dataelements = vDataElements;
                vDataWeb.push(vDocumentIndividual);

                if (vDataWeb.length > 0) {
                    widget.NotificationsUtil.handler().addNotif({ level: 'success', subtitle: "File has been uploaded successfully.Please wait till the Document is getting generated !!", sticky: true });

                    vFinalData.data = vDataWeb;
                    YATGUtils.getCSRFToken().then(csrfToken => {
                        myWidget.callDocWebservice(vFinalData, csrfToken).then(docsData => {

                            var vDocPid = docsData[0].identifier;

                            const vDocName = docsData[0].dataelements.name;
                            vFinalPostBody.docIdentifier = vDocPid;
                            vFinalPostBody.attributeDetails = vFinalDataAttributes;
                            myWidget.updateDocAttributes(vFinalPostBody).then(success => {

                                if (success.status == "No Error") {
                                    widget.NotificationsUtil.handler().addNotif({ level: 'success', subtitle: "Document " + vDocName + " got created successfully!!", sticky: true });
                                    document.getElementById("xlsuploadButton").disabled = false;
                                    document.querySelector("#fileName").textContent = "";
                                    document.querySelector("#inputFile").disabled = false;
                                    document.getElementById("xlsuploadButton").disabled = false;
                                }
                            });
                        });
                    });
                }
            },

            updateDocAttributes: function (vData) {
                return new Promise(function (i, a) {
                    var vURL = vSpaceURL + "/resources/v1/modeler/ReportManagement/EPR/postFormParam";
                    WAFData.authenticatedRequest(vURL, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "Accept": "application/json"
                        },
                        data: JSON.stringify(vData),
                        responseType: "json",
                        timeout: 0,

                        onComplete: function (e) {
                            console.log("::e::", e);
                            i(e);
                        },
                        onFailure: function (e) { console.log(":::failure:::", e); }
                    });
                });
            },
            callDocWebservice: function (vFinalData, csrfToken) {
                return new Promise(function (i, a) {
                    var vURL = vSpaceURL + "/resources/v1/modeler/documents";
                    WAFData.authenticatedRequest(vURL, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "Accept": "application/json",
                            "ENO_CSRF_TOKEN": csrfToken,
                            "SecurityContext": widget.getValue("credentials", t.preferredSecurityContext),
                        },
                        timeout: 0,
                        responseType: "json",
                        data: JSON.stringify(vFinalData),
                        onComplete: function (e) { i(e.data); },
                        onFailure: function (e) { console.log(":::failure:::", e); }
                    });
                });
            },
            // Added for EPR Document Upload : End

            getCellChipIds: function () {
                const chips = document.querySelectorAll('.YATG_wux-controls-selectionChips .YATG_wux-chip-cell-label');
                const selectedIds = Array.from(chips).map(chip => chip.id);
                if (selectedIds.length === 0) {
                    myWidget.setNotificationAlert('warning', "Please Drop Document");
                    return null;
                }
                return selectedIds;
            },

            showPopup: function (show) {
                const popup = document.getElementById("downloadPopup");
                if (popup) popup.style.display = show ? "flex" : "none";
            },

            EPRCompFun: function () {
                const selectedIds = myWidget.getCellChipIds();
                if (!selectedIds) return;
                if (selectedIds.length < 2) {
                    myWidget.setNotificationAlert('warning', "Please Drop Two Documents for comparison");
                    return null;
                }
                YATGUtils.downloadDocument(webServ.EPR_Comparison.url + selectedIds.join(","), webServ.EPR_Comparison.verb);
            },

            EPRRevPDFfun: function () {
                const selectedIds = myWidget.getCellChipIds();
                if (!selectedIds) return;
                if (selectedIds.length > 4) {
                    myWidget.setNotificationAlert('warning', "Restricted to four Documents");
                    return null;
                }
                myWidget.showPopup(true);
                const timeout = setTimeout(function () {
                    myWidget.showPopup(false);
                    myWidget.setNotificationAlert('error', "Request timed out");
                }, 60000);
                try {
                    const responses = WAFData.authenticatedRequest(_baseURL + webServ.EPR_ReviewPDF.url + selectedIds.join(","), {
                        method: webServ.EPR_ReviewPDF.verb,
                        type: "json",
                        params: {
                            current: "true",
                            select: "collabspaces",
                        },
                        headers: {
                            SecurityContext: "VPLMProjectLeader.Company Name.Common Space",
                        },
                    });

                    const xhr = responses.xhr;
                    xhr.onreadystatechange = function () {
                        if (xhr.readyState !== 4) return;
                        clearTimeout(timeout);
                        myWidget.showPopup(false);
                        if (xhr.status === 200) {
                            const { TrialReviewSheetData, ImageData } = JSON.parse(xhr.response);
                            GenerateEPRReviewPDF.createTable(TrialReviewSheetData, ImageData);
                        } else {
                            myWidget.setNotificationAlert('error', "Invalid Document");
                            console.error("Request failed with status:", xhr.status);
                        }
                    };
                } catch (error) {
                    console.error(error);
                    clearTimeout(timeout)
                    myWidget.showPopup(false);
                    myWidget.setNotificationAlert('error', "Invalid Document");
                }
            },

            EprRepFun: function () {
                const selectedIds = myWidget.getCellChipIds();
                if (!selectedIds) return;
                YATGUtils.downloadDocument(webServ.EPR_Report.url + selectedIds.join(","), webServ.EPR_Comparison.verb);
            },

            TPRPdfFun: function () {
                const selectedIds = myWidget.getCellChipIds();
                if (!selectedIds) return;

                if (selectedIds.length !== 1) {
                    myWidget.setNotificationAlert('warning', "Please Drop only one Document");
                    return;
                }

                const apiUrl = _baseURL + webServ.TPR_ReportPDF.url + selectedIds[0];
                const methodWAF = webServ.TPR_ReportPDF.verb;

                myWidget.showPopup(true);
                const timeout = setTimeout(function () {
                    myWidget.showPopup(false);
                    myWidget.setNotificationAlert('error', "Request timed out");
                }, 40000);

                try {
                    const responses = WAFData.authenticatedRequest(apiUrl, {
                        method: methodWAF,
                        type: "json",
                        params: {
                            current: "true",
                            select: "collabspaces",
                        },
                    });

                    const xhr = responses.xhr;
                    xhr.onreadystatechange = function () {
                        if (xhr.readyState !== 4) return;
                        clearTimeout(timeout);
                        myWidget.showPopup(false);
                        if (xhr.status === 200) {
                            const res = JSON.parse(xhr.response);
                            GenerateTPRPDF.createTRPPdfTable(res.documents[0]);
                        } else {
                            console.error("Request failed with status:", xhr.status);
                            myWidget.setNotificationAlert('error', "Failed To Download");
                        }
                    };
                } catch (error) {
                    clearTimeout(timeout);
                    myWidget.showPopup(false);
                    console.error(error);
                    myWidget.setNotificationAlert('error', "Failed To Download");
                }
            },

            dragAndDropFile: function () {
                const maincont = document.createElement("div");

                const parentDiv = this.createElementWithClass('div', 'chg-add-member-assignee-field');

                const controlsDiv = document.createElement('div');
                controlsDiv.classList.add('YATG_wux-controls-abstract', 'YATG_wux-controls-autoComplete');

                const selectionChipsDiv = document.createElement('div');
                selectionChipsDiv.classList.add('YATG_wux-controls-abstract', 'YATG_wux-controls-selectionChips', 'YATG_wux-controls-autoComplete-selectionChips');
                selectionChipsDiv.setAttribute('has-menu', 'true');

                function createChipCell(labelText, docId) {
                    const chipContainer = document.createElement('div');
                    chipContainer.classList.add('YATG_wux-chip-cell-container');
                    chipContainer.setAttribute('draggable', 'true');

                    const img = document.createElement('img');
                    img.id = 'imgid1';
                    img.src = imageURL + 'document_888108.png';
                    img.alt = '';

                    const label = document.createElement('li');
                    label.classList.add('YATG_wux-chip-cell-label');
                    label.id = docId;
                    label.textContent = labelText;

                    const closeButton = document.createElement('li');
                    closeButton.classList.add('YATG_wux-chip-cell-close', 'YATG_wux-ui-3ds', 'YATG_wux-ui-3ds-1x', 'YATG_wux-ui-3ds-close');

                    const closeImg = document.createElement('img');
                    closeImg.id = 'imgid';
                    closeImg.src = imageURL + 'iconActionDelete.png';
                    closeImg.alt = '';

                    closeImg.addEventListener('click', function () {
                        chipContainer.remove();
                    });
                    closeButton.appendChild(closeImg);
                    chipContainer.appendChild(img);
                    chipContainer.appendChild(label);
                    chipContainer.appendChild(closeButton);
                    return chipContainer;
                }
                const lastWidgetDiv = document.createElement('div');
                lastWidgetDiv.classList.add('YATG_wux-controls-lastWidget-selectionChips');
                controlsDiv.appendChild(selectionChipsDiv);
                controlsDiv.appendChild(lastWidgetDiv);
                parentDiv.appendChild(controlsDiv);
                const addedObjectIds = new Set();
                DataDnD.droppable(parentDiv, {
                    enter: function (el, event) {
                        el.classList.add("drag-over");
                    },
                    over: function (el, event) {
                        return true;
                    },
                    leave: function (el, event) {
                        el.classList.remove("drag-over");
                    },
                    drop: function (data, el, event) {
                        const res = JSON.parse(data);
                        res.data.items.forEach(item => {
                            console.log(item);
                            const displayName = item.displayName;
                            const objectId = item.objectId;
                            if (!addedObjectIds.has(objectId)) {
                                const chip = createChipCell(displayName, objectId);
                                selectionChipsDiv.appendChild(chip);
                                addedObjectIds.add(objectId);
                            } else {
                                console.log(`Duplicate drop ignored for objectId: ${objectId}`);
                            }
                        });
                    }
                });
                maincont.appendChild(parentDiv);
                return maincont;
            },

            setNotificationAlert: function (lev, messege) {
                widget.NotificationsUtil.handler().addNotif({ level: lev, subtitle: messege, sticky: true });
            },
        };
        return myWidget;
    });