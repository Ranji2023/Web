define("DS/YATGUtilsServices/YATGUtilsServices",[
    "UWA/Core",
    "UWA/Promise",
    "DS/WAFData/WAFData",
    "DS/PlatformAPI/PlatformAPI",
    "DS/WidgetServices/securityContextServices/SecurityContextServices",
    "DS/i3DXCompassPlatformServices/i3DXCompassPlatformServices",
    "DS/Notifications/NotificationsManagerViewOnScreen",
    "DS/Notifications/NotificationsManagerUXMessages",
    "i18n!DS/YATGUtilsServices/assets/nls/YATG_Notifications.json",
    "text!DS/YATGUtilsServices/assets/YATG_Webservices.json"
],function(UWA,Promise,WAFData,PlatformAPI,SecurityContextServices,i3DXCompassPlatformServices,NotificationsView,NotificationsUX,i18nNotifications,webservicesJson){
    "use strict";

    var webserviceConfig = JSON.parse(webservicesJson);
    var cachedUser = null;

    return{
        GetCurrentSecurityContext: function(){
            return new Promise(function(resolve,reject){
                SecurityContextServices.getInstance().getSecurityContext({
                    onSuccess: function(contextObject){
                        var cleaned = contextObject.SecurityContext.replace("ctx::","");
                        resolve(cleaned);
                    },
                    onFailure:function(){
                        var err ={message:i18nNotifications.error.security_context_fail};
                        reject(err);
                    }
                });
            });
        },
        GetCurrentRole:function(){
            var self = this;
            return new Promise(function(resolve,reject){
                self.GetCurrentSecurityContext().then(
                    function(ctx){
                        var role = ctx.split(".");
                        resolve(role[0]);
                    },
                    function(err){
                        reject(err);
                    }
                );
            });
        },
        GetCurrentUser: function(){
            if(cachedUser == null){
                cachedUser = PlatformAPI.getUser();
            }
            return cachedUser;
        },
        getUserLogin: function(){
            var user = this.GetCurrentUser();
            var login = "";
            if(user !== undefined){
                login = user.login;
            }
            return login;
        },
        get3DSpaceUrl: function(platformServices){
            if(platformServices== null){
                throw new Error("Platform Services not initalized yet");
            }
            return this.getPlatformURL("3DSpace",platformServices);
        },
        get3DSearchUrl: function(platformServices){
            if(platformServices== null){
                throw new Error("Platform Services not initalized yet");
            }
            return this.getPlatformURL("3DSearch",platformServices);
        },
        getPlatformId: function () {
            return (typeof widget !== "undefined" && widget.getValue("x3dPlatformId"))
            ? widget.getValue("x3dPlatformId")
            : "OnPremise";
        },
        retrivePlatformUrl: function(){
            return new Promise(function(resolve, reject){
                i3DXCompassPlatformServices.getPlatformServices({
                    onComplete: function(r){
                        resolve(r);
                    },
                    onFailure: function(e){
                        reject(e);
                    }
                });
            });
        },
        getTenantInfo: function(platformId, tenantsArray){
            var tenant = {};
            for(var i = 0; i< tenantsArray.length;i++){
                if(tenantsArray[i].platformId === platformId){
                    tenant = tenantsArray[i];
                    break;
                }
            }
            return tenant;
        },
        getPlatformURL: function(serviceName, platformServicesArray){
            if(!UWA.is(platformServicesArray,"array")){
                throw new Error("Platform services not initialized yet");
            }
            var platformId = this.getPlatformId();
            var tenant = this.getTenantInfo(platformId,platformServicesArray);
            if(typeof tenant[serviceName]==="undefined"){
                throw new Error("Unknown service "+serviceName);
            }
            return tenant[serviceName];
        },
        _displayNotification: function(level,title,message){
            window.notifs = NotificationsUX;
            NotificationsView.setNotificationManager(window.notifs);

            var notif = {
                level: level,
                title: title,
                message: message,
                sticky: false
            };
            window.notifs.addNotif(notif);
        },
        getClassInformation: function (classId) {
            var self = this;
            return new Promise(function (resolve, reject) {
                var request = {
                    webService: {
                        url: webserviceConfig.getClassifiedItem.url + "/" + classId ,
                        verb: webserviceConfig.getClassifiedItem.verb
                    },
                    callback: {
                        onComplete: function (response) {
                            console.log("API Success for Class Information : ", response);
                            resolve(response);
                        },
                        onFailure: function (error, details) {
                            console.error("API Failed for Class Information : ", error, details);
                            reject(error);
                        }
                    }
                };
                self.SendServerRequest(request);
            })
        },
        SendServerRequest: function(request){
            var self = this;
            var userLogin = this.getUserLogin();
            var options = {};

            options.method = request.webService.verb;
            this.GetCurrentSecurityContext()
                .then(function(securityContext){
                    options.headers = {
                        Accept: request.webService.hasOwnProperty("accept")? request.webService.accept : "application/json",
                        "Content-Type": "application/json",
                        "Accept-Language": widget.lang,
                        SecurityContext: encodeURIComponent("ctx::" + securityContext),
                        SecurityToken: encodeURIComponent(userLogin + "|ctx::" + securityContext + "|" + widget.lang)
                    };

                    options.type = request.webService.hasOwnProperty("type") ? request.webService.type : "json";
                    options.proxy = "passport";
                    options.timeout = (typeof request.timeout !== "undefined") ? request.timeout : 300000; // 5 minutes
                    options.onComplete = request.callback.onComplete;
                    options.onFailure = request.callback.onFailure;
                    options.onTimeout = (typeof request.callback.onTimeout !== "undefined")? request.callback.onTimeout: request.callback.onFailure;

                    var payload = request.data;
                    options.data = JSON.stringify(payload);

                    self.retrivePlatformUrl().then(function(platformServices){
                        var baseUrl = self.get3DSpaceUrl(platformServices);
                        WAFData.authenticatedRequest(baseUrl + request.webService.url, options);
                    });
                })
                .catch(function(err){
                    request.callback.onFailure(err);
                });
        },
        SendSearchRequest: function(request){
            var self = this;
            var userLogin = this.getUserLogin();
            var options = {};

            options.method = request.webService.verb;
            this.GetCurrentSecurityContext()
                .then(function(securityContext){
                    options.headers = {
                        Accept: request.webService.hasOwnProperty("accept")? request.webService.accept : "application/json",
                        "Content-Type": "application/json",
                        "Accept-Language": widget.lang,
                        SecurityContext: encodeURIComponent("ctx::" + securityContext),
                        SecurityToken: encodeURIComponent(userLogin + "|ctx::" + securityContext + "|" + widget.lang)
                    };

                    options.type = request.webService.hasOwnProperty("type") ? request.webService.type : "json";
                    options.proxy = "passport";
                    options.timeout = (typeof request.timeout !== "undefined") ? request.timeout : 300000; // 5 minutes
                    options.onComplete = request.callback.onComplete;
                    options.onFailure = request.callback.onFailure;
                    options.onTimeout = (typeof request.callback.onTimeout !== "undefined")? request.callback.onTimeout: request.callback.onFailure;

                    var payload = request.data;
                    options.data = JSON.stringify(payload);

                    self.retrivePlatformUrl().then(function(platformServices){
                        var baseUrl = self.get3DSearchUrl(platformServices);
                        WAFData.authenticatedRequest(baseUrl + request.webService.url, options);
                    });
                })
                .catch(function(err){
                    request.callback.onFailure(err);
                });
        },
        retrieveObjectInfo: function(objectId){
            console.log("Object ID Inside Retrieve Object Info : ", objectId);
            var self = this;
            return new Promise(function(resolve,reject){
                var request = {
                    data:{
                        "label":"test",
                        "locale": "en",
                        "select_predicate":["ds6wg:revision","ds6w:label"],
                        "query": "flattenedtaxonomies:\"types/VPMReference\"   AND physicalid:"+objectId,
                        "tenant": "OnPremise",
                        "with_nls": true
                    },
                    webService: {url:webserviceConfig.getObjectInfo.url, verb: webserviceConfig.getObjectInfo.verb},
                    callback:{
                        onComplete: function (e){
                            // console.log("Inside Callback");
                            var n = UWA.is(e, "string") ? JSON.parse(e) : e;
                            var objectInfo = {};
                            // console.log("Callback Info : " ,n);
                            if(null !==n && n.hasOwnProperty("results")){
                                // console.log("Inside if : ",n.results.length);
                                for(var o=0;o<n.results.length;o++){
                                    var r = n.results[o];
                                    if(r.hasOwnProperty("attributes")){
                                        console.log("Selection Info : ",r);
                                        for (var a=0;a<r.attributes.length;a++){
                                            var s=r.attributes[a];
                                            // console.log("Attribute : ",s);
                                            if(s.hasOwnProperty("name")){
                                                switch (s.name){
                                                    case "ds6w:what/ds6w:status":
                                                        objectInfo.current = s.dispValue;
                                                        break;
                                                    case "ds6w:where/ds6w:context/ds6w:project":
                                                        objectInfo.project= s.dispValue;
                                                        break;
                                                    case "ds6w:what/ds6w:type":
                                                        objectInfo.type = s.dispValue?.trim() ? s.dispValue : s.value;
                                                        break;
                                                    case "ds6w:label":
                                                        objectInfo.ObjectTitle = s.dispValue;
                                                        break;
                                                    case "ds6w:identifier":
                                                        objectInfo.Identifier = s.dispValue;
                                                        break;
                                                    case "ds6w:who/ds6w:responsible":
                                                        objectInfo.Originator = s.dispValue;
                                                        break;
                                                    case "ds6w:when/ds6w:modified":
                                                        objectInfo.modified = self.getFormattedDate(s.value);
                                                        break;
                                                    case "ds6wg:revision":
                                                        objectInfo.RevisionValue = s.value;
                                                        break;
                                                    case "preview_url":
                                                        objectInfo.PreviewUrlValue = s.value;
                                                        break;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            // console.log("Object Info retrived : ", objectInfo);
                            resolve(objectInfo);
                        },
                        onFailure: function(e){
                            console.log("inside onfailure")
                            reject(e || new Error("Issue retrieving selection informations"));
                        },
                        
                    }
                };
                self.SendSearchRequest(request);
            })
        },
        getFormattedDate: function(modifiedDate){
            const dateRetrived  = new Date(modifiedDate);
            const date = String(dateRetrived.getDate()).padStart(2, '0');
            const month = String(dateRetrived.getMonth() + 1).padStart(2, '0');
            const year = dateRetrived.getFullYear();

            const formattedDate = `${date}/${month}/${year}`;

            return formattedDate;
        }
    };
});