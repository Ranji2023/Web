define("YATGRMUtilsServices/Constants", ["UWA/Core", "UWA/Controls/Abstract"], function (e, t) {
    "use strict";
    return {
        EMPTY_STRING: "",
        SPACE: " ",
        ACTION: "Action",
        EMPTY_JSON_OBJECT: {},
        EMPTY_JSON_ARRAY: [],
        WILD_CHARACTER: "*",
        AMPERSAND: "&",
        ERROR: "error",
        PRIMARY: "primary",
        WARNING: "warning",
        INFO: "info",
        SUCCESS: "success",
        PAD_CURRENT_SECURITY_CONTEXT: "pad_security_ctx",
        PAD_AVAILABLE_SECURITY_CONTEXT: "pad_security_ctx_list",
        PAD_CSRF_TOKEN: "pad_csrf",
        PLATFORM_SERVICES: "platformServices",
        CONTEXT_USER: "context_user",
        CSRF: "CSRF",
        OBJECT_ID: "id",
        PHYSICAL_ID: "physicalid",
        REL_ID: "id[connection]",
        REL_NAME: "name[connection]",
        REL_PHYSICAL_ID: "physicalid[connection]",
        TYPE: "type",
        NAME: "name",
        REVISION: "revision",
        MODIFIED: "modified",
        ACCEPT_APPLICATION_JSON: "application/json",
        SECURITY_CONTEXT_KEY: "SecurityContext",
        CONTENT_TYPE: "Content-Type",
        APPLICATION_URL_ENCODED: "application/x-www-form-urlencoded",
        GET: "GET",
        POST: "POST",
        PUT: "PUT",
        CURRENT_USER: "CURRENT_USER"
    }
}),define("DS/YATGRMUtilsServices/CredentialsServices", ["UWA/Core", "DS/WAFData/WAFData", "DS/i3DXCompassPlatformServices/i3DXCompassPlatformServices", "DS/YATGRMUtilsServices/SettingsManagement", "DS/Notifications/NotificationsManagerUXMessages", "DS/Notifications/NotificationsManagerViewOnScreen", "i18n!DS/ENOXDocumentControlUI/assets/nls/DocEnhancers","DS/YATGRMUtilsServices/NotificationUtils"], function (e, t, n, o, i, a, r,NotificationsUtil) {
    "use strict";
    return function () {
        var e = {


            preferredSecurityContext: void 0,
            serverPreferredSecurityContext: void 0,
            security_context_list: [],
            platform_list: [],
            notify: !0,
            init: function (e, t) {

                console.log("inside init in cred services ------------------------------>")
                var n = this;
                widget.addEvent("onPlatformIdChange", n.onPlatformIdChange, n), widget.addEvent("endEdit", n.onPreferenceEditDone, n), widget.addEvent("widget-title-needs-update", n.onTitleNeedsUpdate, n), a.setNotificationManager(i), n.initPlatform(function (i) {
                     widget.setValue("x3dPlatformId", i.platformId), n.initCredentials(function (t) {
                        o.addSetting("pad_security_ctx", t), widget.setValue("credentials", t), widget.setValue("xPref_CREDENTIAL", t), widget.setValue("tenantAware", !0), e(t)
                    }, t)
                }, t)
            },
            initPlatform: function (e, t) {
                var o = this;
                o.preferredPlatformId = widget.getValue("x3dPlatformId") ? widget.getValue("x3dPlatformId") : "OnPremise", console.log("preferredPlatformId=" + o.preferredPlatformId), o.nonOnPremisePlatforms = 0, n.getPlatformServices({
                    onComplete: function (n) {
                        if (null != n)
                            if (0 != n.length) {
                                var i = n.find(e => e.platformId == o.preferredPlatformId);
                                null == i && (i = n[0], o.showNotification({
                                    level: "warning",
                                    title: r.get("PlatformChanged"),
                                    subtitle: r.get("PreferredPlatformNotAvailable", {
                                        platform: i.displayName
                                    }),
                                    sticky: !1
                                }), console.log("Preferred Platform not available, using the first one")), o.platform_list = n, o.preferredPlatformId = i.platformId, o.preferredPlatform = o.platform_list.find(e => e.platformId == o.preferredPlatformId), n.forEach(e => {
                                    "OnPremise" != e.platformId && o.nonOnPremisePlatforms++
                                }), e(o.preferredPlatform)
                            } else t("ZeroPlatformsAvailable");
                        else t("NoPlatformsAvailable")
                    },
                    onFailure: function () {
                        t("FailedToGetPlatforms")
                    }
                })
            },
            initCredentials: function (e, n) {
                var o = this;
                if (o.preferredSecurityContext = widget.getValue("credentials"), console.log("preferredSecurityContext=" + o.preferredSecurityContext), e) {
                    var i = o.preferredPlatform["3DSpace"] + "/resources/modeler/pno/person?current=true";
                    i += "&select=preferredcredentials&select=collabspaces", i += "&tenant=" + o.preferredPlatformId, t.authenticatedRequest(i, {
                        method: "GET",
                        type: "json",
                        headers: {
                            Accept: "application/json",
                            "Accept-Language": widget.lang
                        },
                        onComplete: function (t) {
                            o.username = t.name, o.serverPreferredSecurityContext = void 0, o.security_context_list = [];
                            var n = t.preferredcredentials;
                            if (n.collabspace && n.role && n.organization && (o.serverPreferredSecurityContext = n.role.name + "." + n.organization.name + "." + n.collabspace.name), o.multiOrg = !1, t.collabspaces && t.collabspaces.length > 0) {
                                for (var i = void 0, a = 0; a < t.collabspaces.length; a++)
                                    for (var r = 0; r < t.collabspaces[a].couples.length; r++) {
                                        var s = t.collabspaces[a].couples[r];
                                        null == i && (i = s.organization.name), i != s.organization.name && (o.multiOrg = !0);
                                        var c = s.role.name + "." + s.organization.name + "." + t.collabspaces[a].name;
                                        t.collabspaces[a].title || (t.collabspaces[a].title = t.collabspaces[a].name), s.organization.title || (s.organization.title = s.organization.name), s.role.nls || (s.role.nls = s.role.name);
                                        var l = t.collabspaces[a].title + " ● " + s.organization.title + " ● " + s.role.nls,
                                            d = t.collabspaces[a].title + " ● " + s.role.nls;
                                        o.security_context_list.push({
                                            value: c,
                                            withorg_nls: l,
                                            withoutorg_nls: d,
                                            collabspaceTitle: t.collabspaces[a].title
                                        })
                                    }
                                o.serverPreferredSecurityContext || (console.log("No preferred credential on server, use the first one available"), o.serverPreferredSecurityContext = o.security_context_list[0].value)
                            }
                            if (!o.security_context_list.some(e => e.value == o.preferredSecurityContext)) {
                                console.log("widget preferred credential no longer available, use server preferred credential"), o.serverPreferredSecurityContext && (o.preferredSecurityContext = o.serverPreferredSecurityContext);
                                o.security_context_list.find(e => e.value == o.preferredSecurityContext)
                            }
                            o.addPreferences(), o.preferredPlatform.security_context_list = o.security_context_list, e(o.preferredSecurityContext)
                        },
                        onFailure: n
                    })
                }
            },
            addPreferences: function () {
                var e = this;
                widget.addPreference({
                    name: "x3dPlatformId",
                    defaultValue: e.preferredPlatformId,
                    type: 0 == e.nonOnPremisePlatforms ? "hidden" : "list",
                    label: r.get("3DEXPERIENCEPlatform"),
                    options: e.platform_list.map(function (e) {
                        return {
                            label: e.displayName,
                            value: e.platformId
                        }
                    }),
                    onchange: "onPlatformIdChange",
                    disabled: e.platform_list.length < 2
                }), widget.addPreference({
                    name: "credentials",
                    defaultValue: e.preferredSecurityContext,
                    type: "list",
                    label: r.get("Credentials"),
                    options: e.security_context_list.sort(function (t, n) {
                        return e.multiOrg ? t.withorg_nls < n.withorg_nls ? -1 : t.withorg_nls > n.withorg_nls ? 1 : 0 : t.withoutorg_nls < n.withoutorg_nls ? -1 : t.withoutorg_nls > n.withoutorg_nls ? 1 : 0
                    }).map(function (t) {
                        return {
                            label: e.multiOrg ? t.withorg_nls : t.withoutorg_nls,
                            value: t.value
                        }
                    })
                })
            },
            onPlatformIdChange: function (t, n) {
                var o = this;
                "x3dPlatformId" == t && widget.credentials == o && o.preferredPlatformId != n && (o.preferredPlatformId = n, o.preferredPlatform = o.platform_list.find(e => e.platformId == o.preferredPlatformId), o.notify = !1, e.initCredentials(function () {
                    o.notify = !0
                }, function () { }))
            },
            onPreferenceEditDone: function (e) {
                var t = this;
                widget.credentials == t && (e.submitted || (t.preferredSecurityContext = widget.getValue("credentials"),widget.getValue("credentials",t.preferredSecurityContext), widget.setValue("xPref_CREDENTIAL", t.preferredSecurityContext), t.preferredPlatformId = widget.getValue("x3dPlatformId") ? widget.getValue("x3dPlatformId") : "OnPremise", t.preferredPlatform = t.platform_list.find(e => e.platformId == t.preferredPlatformId), t.security_context_list = t.preferredPlatform.security_context_list, t.addPreferences()))
                var currentSecContext = widget.getValue("credentials",t.preferredSecurityContext);
                var currentServerSecContext = widget.getValue("credentials",t.serverPreferredSecurityContext);
                console.log(`prefered security context ${currentSecContext} and server preferd security context ${currentServerSecContext}`);
                widget.NotificationsUtil = new NotificationsUtil();
                widget.NotificationsUtil.handler().addNotif({ level: 'success', subtitle: `credentials set to ${currentSecContext}`, sticky: false });
            },
            showNotification: function (e) {
                this.notify && i.addNotif(e)
            },
            onTitleNeedsUpdate: function (e) {
                widget.credentials == this && widget.setTitle(e.selectionTitle)
            }
        };
        return e
    }
})