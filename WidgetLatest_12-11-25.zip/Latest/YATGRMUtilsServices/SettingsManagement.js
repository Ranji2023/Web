define("DS/YATGRMUtilsServices/SettingsManagement", ["UWA/Class", "YATGRMUtilsServices/Constants"], function (e, t) {
    "use strict";
    return e.singleton({
        init: function () {
            this.isPlatformInitialized = !0
        },
        addSetting: function (e, t) {
            if (!this.isPlatformInitialized) throw new Error("Platformservices not initialized");
            widget[e] && console.log("Setting is already in use"), widget[e] = t
        },
        getSetting: function (e) {
            return widget[e] || ""
        },
        getPlatformURLs: function () {
            return this.getSetting(t.PLATFORM_SERVICES)
        },
        getPlatformId: function () {
            return widget.getValue("x3dPlatformId") ? widget.getValue("x3dPlatformId") : "OnPremise"
        },
        get3DSpaceURL: function () {
            return this.getPlatformURLs().get3DSpaceURL()
        }
    })
})