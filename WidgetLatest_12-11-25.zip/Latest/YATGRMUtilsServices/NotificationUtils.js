define("DS/YATGRMUtilsServices/NotificationUtils", [
    "DS/Notifications/NotificationsManagerUXMessages",
    "DS/Notifications/NotificationsManagerViewOnScreen"],
    function (NotificationsManagerUXMessages, NotificationsManagerViewOnScreen) {
        'use strict';
        let _notif_manager = null;
        let Notify = function () {
            _notif_manager = NotificationsManagerUXMessages;
            NotificationsManagerViewOnScreen.setNotificationManager(_notif_manager);
            NotificationsManagerViewOnScreen.setStackingPolicy(9);
        };
        Notify.prototype.handler = function () {
            NotificationsManagerViewOnScreen.inject(document.body);
            return _notif_manager;
        };
        Notify.prototype.notifview = function () {
            return NotificationsManagerViewOnScreen;
        };
        return Notify;
    }
)