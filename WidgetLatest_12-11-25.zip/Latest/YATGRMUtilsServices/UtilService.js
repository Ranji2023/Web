define("DS/YATGRMUtilsServices/UtilService", [
    "DS/i3DXCompassPlatformServices/i3DXCompassPlatformServices",
    "DS/WAFData/WAFData",
    "UWA/Class/Promise",
    "DS/YATGRMUtilsServices/NotificationUtils",
], function (i3DXCompassPlatformServices, WAFData, t, NotificationsUtil) {
    widget.NotificationsUtil = new NotificationsUtil();
    var utils = {
        getURLs: function () {
            return new Promise(function (i, a) {
                i3DXCompassPlatformServices.getServiceUrl({
                    serviceName: '3DSpace',
                    onComplete: function (e) {
                        i(e[0]);
                    }
                });
            });
        },
        getSecurityContext: function () {
            return new Promise(function (t, i) {
                utils.getURLs().then(results => {
                    WAFData.authenticatedRequest(results.url + "/resources/pno/person/getsecuritycontext?current=true&select=preferredcredentials&select=collabspaces", {
                        method: "GET",
                        headers: {
                            "Accept": "application/json",
                        },
                        timeout: 864e5,
                        type: "json",
                        onComplete: function (e) {
                            t(e);
                        },
                        onFailure: function (e, t) {
                            var n = e.message;
                        },
                        onTimeout: function () {
                            console.log("time out")
                        },
                    });
                });
            });
        },
        getCSRFToken: function () {
            return new Promise(function (i, a) {
                utils.getURLs().then(results => {
                    WAFData.authenticatedRequest(results.url + "/resources/v1/application/CSRF", {
                        method: "GET",
                        headers: {
                            "Content-Type": "application/json",
                            "Accept": "application/json",
                            "SecurityContext": widget.getValue("credentials", t.preferredSecurityContext),
                        },
                        responseType: "json",
                        onComplete: function (e) { i(e.csrf.value); },
                        onFailure: function (e) {
                            console.log(":::failure:::", e);
                        }
                    });
                })
            });
        },
        getCurrentUser: function () {
            return new t(function (e, t) {
                i3DXCompassPlatformServices.getUser({
                    onComplete: function (t) {
                        e({
                            id: t.id,
                            email: t.email,
                            firstName: t.firstname,
                            lastName: t.lastname,
                        });
                    },
                    onFailure: t,
                });
            });
        },

        getCredentialsList: function (_baseURL) {
            return new Promise((resolve, reject) => {
                utils.getURLs().then(results => {
                    var url = results.url + '/resources/modeler/pno/person?tenant=OnPremise&current=true&select=collabspaces&select=preferredcredentials';

                    WAFData.authenticatedRequest(url, {
                        method: "GET",
                        type: "json",
                        headers: {
                            Accept: "application/json",
                            "Accept-Language": widget.lang
                        },
                        onComplete: function (data) {
                            if (data && data.collabspaces && data.collabspaces.length > 0) {
                                var credentialsList = [];
                                data.collabspaces.forEach(function (collabspace) {
                                    collabspace.couples.forEach(function (couple) {
                                        var contextValue = couple.role.name + "." + couple.organization.name + "." + collabspace.name;
                                        var contextWithOrg = collabspace.title + " ● " + couple.organization.title + " ● " + couple.role.nls;
                                        var contextWithoutOrg = collabspace.title + " ● " + couple.role.nls;

                                        credentialsList.push({
                                            value: contextValue,
                                            withOrgNls: contextWithOrg,
                                            withoutOrgNls: contextWithoutOrg,
                                            collabspaceTitle: collabspace.title
                                        });
                                    });
                                });

                                resolve(credentialsList);
                            } else {
                                reject("NoCollabspacesFound");
                            }
                        },
                        onFailure: function () {
                            reject("FailedToFetchCredentials");
                        }
                    });

                });
            });
        },

        downloadDocument: function (url, verb) {
            const popup = document.getElementById("downloadPopup");
            if (popup) popup.style.display = "flex";
            const timeout = setTimeout(function () {
                if (popup) popup.style.display = "none";
                widget.NotificationsUtil.handler().addNotif({ level: 'error', subtitle: "Requested Timout", sticky: true });
            }, 40000);


            utils.getURLs().then(results => {
                try {
                    fetch(results.url + url, {
                        method: verb,
                    })
                        .then(async response => {
                            if (!response.ok) {
                                throw new Error("Network response was not ok");
                            }

                            const disposition = response.headers.get("Content-Disposition");
                            let filename = "report.xlsx";

                            if (disposition && disposition.includes("filename=")) {
                                const match = disposition.match(/filename="?(.+?)"?$/);
                                if (match && match[1]) {
                                    filename = match[1];
                                }
                            }

                            const blob = await response.blob();
                            return ({ blob, filename });
                        })
                        .then(({ blob, filename }) => {
                            const link = document.createElement('a');
                            link.href = URL.createObjectURL(blob);
                            link.download = filename;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            URL.revokeObjectURL(link.href);
                            clearTimeout(timeout);
                            if (popup) popup.style.display = "none";

                        })
                        .catch(error => {
                            console.error("Download failed:", error);
                            if (popup) popup.style.display = "none";
                        })

                } catch (error) {
                    clearTimeout(timeout);
                    console.error("Error during request:", error);
                    if (popup) popup.style.display = "none";
                    widget.NotificationsUtil.handler().addNotif({ level: 'error', subtitle: "Failed To Download", sticky: true });

                }
            })

        },
    };
    return utils;
})